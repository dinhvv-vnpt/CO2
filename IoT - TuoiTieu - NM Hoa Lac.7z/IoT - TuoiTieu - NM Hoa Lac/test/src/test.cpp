/*
 * main.cpp
 *
 *  Created on: May 10, 2017
 *      Author: MANHBT
 */

#include "clsDeviceManager.h"
#include "config.h"
#include "Debug.h"
#include <mutex>


#include <TransSmartBus/clsTransSmartBus.h>

using namespace AHGSystems;
using namespace TransSmartBus;

int onDeviceStatusChanged(std::string szDeviceID, char* pcStatus, void* pvParent);
int main()
{
	clsDeviceManager::Instance()->RegisterCallback(DEV_EVENT_TYPE_ON_STATUS_CHANGED, (CallbackFunction)onDeviceStatusChanged, "985dad3ed9c7");

#if 1
	std::list<std::string> lstDevList = clsDeviceManager::Instance()->GetRegisteredDeviceList();

	std::cout << "List of registered device: " << std::endl;

	for (auto itr = lstDevList.begin(); itr != lstDevList.end(); itr++)
	{
		std::cout <<"\t" << itr->c_str() << " type: " << clsDeviceManager::Instance()->GetDeviceType(itr->c_str()) << std::endl;
	}

	std::list<std::string> lstCmd = clsDeviceManager::Instance()->GetListCommand();

	std::cout << "List of Supported commands: " << std::endl;

	for (auto itr = lstCmd.begin(); itr != lstCmd.end(); itr++)
	{
		std::cout <<"\t" << itr->c_str() << std::endl;
	}

	std::cout << "Number of registered device: " <<
			clsDeviceManager::Instance()->GetNumberOfRegisteredDevice() << std::endl;
#endif


	LREP("Main thread started!");

	do {

#if 1
	clsDeviceManager::Instance()->ExecuteCommand("TUOI-TIEU-HOA-LACPump1On");
	clsDeviceManager::Instance()->ExecuteCommand("TUOI-TIEU-HOA-LACPump2On");
	sleep(1);
	clsDeviceManager::Instance()->ExecuteCommand("TUOI-TIEU-HOA-LACPump1Off");
	clsDeviceManager::Instance()->ExecuteCommand("TUOI-TIEU-HOA-LACPump2Off");				// 1 min
	sleep(1);
//	clsDeviceManager::Instance()->ExecuteCommand("TUOI-TIEU-HOA-LACGetStatus");
#endif

#if 0
//	LREP("\r\nGateway Stat: %s", clsDeviceManager::Instance()->GetCurrentStatusDevice("GATEWAY"));
	LREP("\r\nGateway Stat: %s", clsDeviceManager::Instance()->GetCurrentStatusDevice("DELCO-HYDROPONIC-TANK_4"));

	std::this_thread::sleep_for(std::chrono::milliseconds(2000));


#endif


#if 0
	LREP_RAW(".");
	std::this_thread::sleep_for(std::chrono::milliseconds(100));


#endif


#if 0
//	LREP_RAW(".");

//	std::this_thread::sleep_for(std::chrono::seconds(2));
//	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_1CircularPump1TurnOn"));
//	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_2CircularPump2TurnOn"));
//	std::this_thread::sleep_for(std::chrono::seconds(2));
//		LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_2CircularPump1TurnOff"));
//		LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_2CircularPump2TurnOff"));

	std::string cmd;
	  while (1) {
	    std::cout << "Enter your command: " << std::endl;
	    std::cin>>cmd;
	    int iRet = clsDeviceManager::Instance()->ExecuteCommand(cmd);
	    LREP("\r\n result = %d", iRet);
	  }
#endif


#if 0
	LREP_RAW("\r\nTank1 status %s", AHGSystems::clsDeviceManager::Instance()->GetCurrentStatusDevice("DELCO-HYDROPONIC-TANK_1"));
//	std::this_thread::sleep_for(std::chrono::seconds(10));
	LREP_RAW("\r\nCooling status %s", AHGSystems::clsDeviceManager::Instance()->GetCurrentStatusDevice("DELCO-HYDROPONIC-AIR-COOLING_1"));
	std::this_thread::sleep_for(std::chrono::seconds(10));

#endif

#if 0
	LREP("Execute command: ");
	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_1FreshWaterValveTurnOn"));
	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_1ECPumpATurnOn"));
	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_1ECPumpBTurnOn"));
	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_1AeratorTurnOn"));
	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_1CircularPump1TurnOn"));
	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_1CircularPump2TurnOn"));

	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_2FreshWaterValveTurnOn"));
	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_2ECPumpATurnOn"));
	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_2ECPumpBTurnOn"));
	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_2AeratorTurnOn"));
	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_2CircularPump1TurnOn"));
	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_2CircularPump2TurnOn"));

	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_3FreshWaterValveTurnOn"));
	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_3ECPumpATurnOn"));
	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_3ECPumpBTurnOn"));
	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_3AeratorTurnOn"));
	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_3CircularPump1TurnOn"));
	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_3CircularPump2TurnOn"));

	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_4FreshWaterValveTurnOn"));
	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_4ECPumpATurnOn"));
	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_4ECPumpBTurnOn"));
	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_4AeratorTurnOn"));
	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_4CircularPump1TurnOn"));
	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_4CircularPump2TurnOn"));

	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_5FreshWaterValveTurnOn"));
	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_5ECPumpATurnOn"));
	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_5ECPumpBTurnOn"));
	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_5AeratorTurnOn"));
	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_5CircularPump1TurnOn"));
	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_5CircularPump2TurnOn"));

	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-AIR-COOLING_1FanTurnOn"));
	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-AIR-COOLING_1SprayPumpTurnOn"));
	std::this_thread::sleep_for(std::chrono::milliseconds(10000));
	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_1FreshWaterValveTurnOff"));
	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_1ECPumpATurnOff"));
	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_1ECPumpBTurnOff"));
	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_1AeratorTurnOff"));
	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_1CircularPump1TurnOff"));
	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_1CircularPump2TurnOff"));

	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_2FreshWaterValveTurnOff"));
	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_2ECPumpATurnOff"));
	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_2ECPumpBTurnOff"));
	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_2AeratorTurnOff"));
	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_2CircularPump1TurnOff"));
	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_2CircularPump2TurnOff"));

	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_3FreshWaterValveTurnOff"));
	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_3ECPumpATurnOff"));
	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_3ECPumpBTurnOff"));
	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_3AeratorTurnOff"));
	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_3CircularPump1TurnOff"));
	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_3CircularPump2TurnOff"));

	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_4FreshWaterValveTurnOff"));
	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_4ECPumpATurnOff"));
	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_4ECPumpBTurnOff"));
	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_4AeratorTurnOff"));
	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_4CircularPump1TurnOff"));
	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_4CircularPump2TurnOff"));

	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_5FreshWaterValveTurnOff"));
	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_5ECPumpATurnOff"));
	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_5ECPumpBTurnOff"));
	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_5AeratorTurnOff"));
	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_5CircularPump1TurnOff"));
	LREP("turn_off: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_5CircularPump2TurnOff"));

	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-AIR-COOLING_1FanTurnOff"));
	LREP("turn_on: %d", clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-AIR-COOLING_1SprayPumpTurnOff"));

	std::this_thread::sleep_for(std::chrono::milliseconds(10000));
#endif

#if 0
	LREP("Execute command: ");
	clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_1Run");
	std::this_thread::sleep_for(std::chrono::milliseconds(2000));
	clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_1Stop");
	std::this_thread::sleep_for(std::chrono::milliseconds(2000));

	LREP_RAW(".");
	std::this_thread::sleep_for(std::chrono::milliseconds(100));

	LREP("Execute command: ");
	clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_1Run");
	std::this_thread::sleep_for(std::chrono::milliseconds(2000));
	clsDeviceManager::Instance()->ExecuteCommand("DELCO-HYDROPONIC-TANK_1Stop");
	std::this_thread::sleep_for(std::chrono::milliseconds(2000));
#endif				
		} while(1);

	return 0;

}



int onDeviceStatusChanged(std::string szDeviceID, char* pcStatus,  void* pvParent)
{

	LREP("\r\n\%s updated, params: %s\r\n", szDeviceID.c_str(), pcStatus);
//	LREP_RAW("@");
	return 0;
}
