/*
 * processor.h
 *
 *  Created on: Jun 5, 2017
 *      Author: buiti
 */

#ifndef PROCESSOR_PROCESSOR_H_
#define PROCESSOR_PROCESSOR_H_

#include <ahg.h>
#include <config.h>

//#if (APP_TYPE == APP_TYPE_SMART_HOME)
#include <clsSMBusProcessor.h>
#include <clsRSPProcessor.h>
//#endif

#endif /* PROCESSOR_PROCESSOR_H_ */
