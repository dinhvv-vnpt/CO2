/*
 * IProcessor.h
 *
 *  Created on: May 30, 2017
 *      Author: buiti
 */

#ifndef PROCESSOR_IPROCESSOR_H_
#define PROCESSOR_IPROCESSOR_H_

namespace AHGSystems {

class IProcessor {
public:
	IProcessor();
	virtual ~IProcessor();

	virtual void Process(void *pvArgs) = 0;
};

} /* namespace AHGSystems */

#endif /* PROCESSOR_IPROCESSOR_H_ */
