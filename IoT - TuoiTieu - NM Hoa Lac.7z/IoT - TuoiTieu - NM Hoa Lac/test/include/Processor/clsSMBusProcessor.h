/*
 * clsSMBusProcessor.h
 *
 *  Created on: May 30, 2017
 *      Author: buiti
 */

#ifndef PROCESSOR_CLSSMBUSPROCESSOR_H_
#define PROCESSOR_CLSSMBUSPROCESSOR_H_

#include <Processor/IProcessor.h>
#include <IDevice.h>
#include <list>
#include <memory>

namespace AHGSystems {

class clsSMBusProcessor: public IProcessor {

private:
	clsSMBusProcessor();

public:
	static clsSMBusProcessor* 	Instance();
	virtual ~clsSMBusProcessor();
	void 	RegisterDevice(std::shared_ptr<IDevice> pDevice);

	void 	Process(void* pvFrame) override;
};

} /* namespace AHGSystems */

#endif /* PROCESSOR_CLSSMBUSPROCESSOR_H_ */
