/*
 * interfaces.h
 *
 *  Created on: Jun 5, 2017
 *      Author: buiti
 */

#ifndef INTERFACES_INTERFACES_H_
#define INTERFACES_INTERFACES_H_

#include <ahg.h>
#include <config.h>


#if (APP_TYPE == APP_TYPE_SMART_AGRICULTURE)
#include <clsRS485.h>
#elif(APP_TYPE == APP_TYPE_SMART_FACTORY)
#elif(APP_TYPE == APP_TYPE_SMART_HOME)
#include <clsI2C.h>
#include <clsRS485pthread.h>
#endif


#endif /* INTERFACES_INTERFACES_H_ */
