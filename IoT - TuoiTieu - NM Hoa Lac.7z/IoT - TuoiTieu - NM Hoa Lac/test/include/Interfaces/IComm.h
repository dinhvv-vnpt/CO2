/*
 * IComm.h
 *
 *  Created on: May 10, 2017
 *      Author: MANHBT
 */

#ifndef ICOMM_H_
#define ICOMM_H_
#include <string>
#include <stdint.h>
#include <ahg.h>

namespace AHGSystems {

class IComm {
private:
public:
	IComm();
	virtual ~IComm();
	virtual int16_t Write(uint8_t *pu8Data, uint16_t u16Len) = 0;
	virtual int16_t Read(uint8_t *pu8Data, uint16_t u16Len) = 0;
	virtual bool 	IsDataReady(int iMilis) = 0;
	virtual uint8_t	ReadByte() = 0;
	virtual bool 	WriteByte(uint8_t u8Data) = 0;
};

} /* namespace Agriculture */

#endif /* ICOMM_H_ */

