/*
 * clsLogger.h
 *
 *  Created on: Aug 9, 2017
 *      Author: MANHBT
 */

#ifndef COMMON_CLSLOGGER_H_
#define COMMON_CLSLOGGER_H_
#include <string>
#include <ctime>
#include <chrono>
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <stdint.h>
#include <ctype.h>

namespace AHGSystems {

class clsLogger {
private:
	std::string m_szLogFileName;

	time_t m_t;  // get time now
	struct tm * m_thistime;
public:
	clsLogger();
	clsLogger(std::string szFileName);
	virtual ~clsLogger();

	void SetFileName(std::string szFileName);

	void LogError(const char* string, ...);
	void LogWarning(const char* string, ...);
	void LogInfo(const char* string, ...);



};

} /* namespace AHGSystems */


#endif /* COMMON_CLSLOGGER_H_ */
