/**
 * @file Debug.h
 * @author binhnt42
 * @brief Debug util class
 * @addtogroup lib
 * @{
 * @defgroup lib_debug Debug
 * @brief Define LREP_x function for print debug string
 * @{
  */
#ifndef __LIB_DEBUG_H__
#define __LIB_DEBUG_H__
//#include "IDebug.h"
#include <stdlib.h>
#include "lib_defines.h"

#undef LREF
#undef LREF_ERROR
#undef LREF_WARNING

#define KNRM  "\x1B[0m"
#define KRED  "\x1B[31m"
#define KGRN  "\x1B[32m"
#define KYEL  "\x1B[33m"
#define KBLU  "\x1B[34m"
#define KMAG  "\x1B[35m"
#define KCYN  "\x1B[36m"
#define KWHT  "\x1B[37m"


void debug_nothing(const char* sz, ...);

#define LREF_DUMP               lib::Debug::_DUMP
#ifdef COMPILER_MSC
#define LREF_RAW(x, ...)        lib::Debug::_PRINT(x , __VA_ARGS__)
#define LREF(x, ...)            lib::Debug::_PRINT(x "\n", __VA_ARGS__)
#define LREF_ERROR(x, ...)      lib::Debug::_PRINT("ERR :%d:%s " x "\n", __LINE__, __FILE__, __VA_ARGS__)
#define LREF_WARNING(x, ...)    lib::Debug::_PRINT("WARN:%d:%s " x "\n", __LINE__, __FILE__, __VA_ARGS__)
#elif defined(COMPILER_GCC)
#define LREF_RAW(s, args...)     lib::Debug::_PRINT(s, ##args)
#define LREF(s, args...)         lib::Debug::_PRINT(KGRN "[Firmware] " s "\n" KNRM, ##args)
#define LREF_ERROR(s, args...)   lib::Debug::_PRINT(KRED "[Firmware][ERROR] :%d:%s " s "\n" KNRM, __LINE__, __FILE__, ##args)
#define LREF_WARNING(s, args...) lib::Debug::_PRINT(KYEL "[Firmware][WARNING] " s "\n" KNRM, ##args)
#endif

#if (LREP_DISABLE == 1)
#undef LREF
#define LREF			debug_nothing
#endif
#if (LREP_ERROR_DISABLE == 1)
#undef LREF_ERROR
#define LREF_ERROR		debug_nothing
#endif
#if (LREP_WARNING_DISABLE == 1)
#undef LREF_WARNING
#define LREF_WARNING	debug_nothing
#endif
#if (LREP_RAW_DISABLE == 1)
#undef LREF_RAW
#define LREF_RAW		debug_nothing
#endif

#define LREP            LREF            ///< Print debug string with format (*str, arg1, arg2,...) terminate by new line
#define LREP_RAW        LREF_RAW        ///< Print debug string with format (*str, arg1, arg2,...)
#define LREP_ERROR      LREF_ERROR      ///< Print debug string with format (*str, arg1, arg2,...) with 'error' begin
#define LREP_WARNING    LREF_WARNING    ///< Print debug string with format (*str, arg1, arg2,...) with  'warning' begin
#define LREP_DUMP       LREF_DUMP       ///< Dump memory to debug channel, format (pointer, length, debug_string)
/** @brief Debug callback
 * @param text Text debug string
 * @param obj  Callback object
 */
typedef void (*debug_callback)(const char* text, void* obj);

namespace lib {
/**
 * @brief Debug class
 */
class Debug {
public:
    Debug();
    virtual ~Debug();
    /**
     * @brief Set callback function for debug
     * @param fxn   function
     * @param obj   object
     * @note if callback is not set, debug will print to stdout
     */
    static void SetCallback(debug_callback fxn, void* obj);
    
    static void _PRINT(const char* string, ...);
    static void _DUMP(const void* data, int len, const char* string, ...);

private:
    static debug_callback s_callback;
    static void*          s_obj;

};

}


#endif
/** @} */
/** @} */
