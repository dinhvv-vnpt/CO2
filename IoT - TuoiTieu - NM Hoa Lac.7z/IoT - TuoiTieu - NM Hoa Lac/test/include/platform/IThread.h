/**
 * @file IThread.h
 * @brief Thread interface
 * @addtogroup lib
 * @{
 * @defgroup lib_thread Thread
 * @brief Thread
 * @{
 */
#ifndef __LIB_ITHREAD_H__
#define __LIB_ITHREAD_H__

/**
 * @brief Thread interface
 */
class IThread
{
public :
	/**
	 * @brief Thread function type
	 * @param pInput Input object
	 * @param pIsTerminate Terminate flag
	 */
    typedef void (*FXN)(void* pInput, bool *pIsTerminate);
    /**
     * @brief Constructor
     * @param fxn Thread function
     */
    IThread(FXN fxn);
    virtual ~IThread();
    /**
     * @brief Start thread
     * @param pInput Input object
     * @return int
     */
    virtual int Start(void* pInput) = 0;
    /**
     * @brief Stop thread
     * @param timeout Timeout for terminate thread
     */
    virtual int Stop(int timeout) = 0;
    /**
     * @brief Check thread is running
     * @return true: is running, false: not running
     */
    bool IsRunning();

protected:
    struct FXN_INFO
    {
        FXN     fxn;
        void*   pInput;
    };

    bool            m_bIsRunning;
    bool            m_bIsTerminate;
    struct FXN_INFO m_fxnInfo;
};

#endif
/** @} */
/** @} */
