#ifndef __OS_THREAD_H__
#define __OS_THREAD_H__
#include <IThread.h>
#include <pthread.h>

void* Platform_Thread_run(void *param);
class Platform_Thread: public IThread
{
public:
    Platform_Thread(FXN fxn);
    virtual ~Platform_Thread();

    int Start(void* pInput);
    int Stop(int timeout = 1000);

    static void SleepMs(int ms);
    static void SleepUs(int us);
    
    friend void* Platform_Thread_run(void *param);
    void* m_obj;
private:
    pthread_t m_threadHandle;
    
};

#endif
