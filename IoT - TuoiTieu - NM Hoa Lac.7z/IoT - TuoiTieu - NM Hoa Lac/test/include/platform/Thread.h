/**
 * @file Thread.h
 * @addtogroup lib
 * @{
 * @defgroup lib_thread Thread
 * @{
 */
#ifndef __LIB_THREAD_H__
#define __LIB_THREAD_H__
#include "platform/Platform_Thread.h"


/**
 * @brief Thread class
 */
class Thread: public Platform_Thread
{
public:
	/**
	 * @brief Constuctor
	 * @param fxn Thread function
	 */
    Thread(FXN fxn);
    virtual ~Thread();
};

#endif
/** @} */
/** @} */
