/*
 * clsDeviceManager.h
 *
 *  Created on: May 10, 2017
 *      Author: MANHBT
 */

#ifndef CLSDEVICEMANAGER_H_
#define CLSDEVICEMANAGER_H_
#include <string>
#include <stdint.h>
#include <thread>
#include <list>
#include <unordered_map>
#include <memory>
#include <mutex>
#include <Thread.h>
#include <IDevice.h>
#include <Debug.h>

#include <devices.h>
#include <interfaces.h>
#include <processor.h>



namespace AHGSystems {


typedef  enum	_DevManMode
{
	OP_MODE_AUTO = 0x00,
	OP_MODE_MANUAL
} DevManMode_t;



class clsDeviceManager {
private:

	clsDeviceManager();

	static void 			SensorUpdateProc(void* pArgs, bool *pIsTerminate);

	static void 			InputDeviceReadProc(void *pArgs, bool *bIsTerminate);

	static void 			UpdateDevices();
	static void 			DeviceInitialize();
	static void 			RegisterDevice(std::string szDeviceID, std::shared_ptr<IDevice> pDevice);
	static void 			RemoveDevice(std::string szDeviceID);

	static void				DisableRelayBoxButtons(bool bDisable);
	static void 			OnModeChanged(void *pvParent);
public:
	static clsDeviceManager* Instance();
	virtual ~clsDeviceManager();

	std::list<std::string> 	GetRegisteredDeviceList();
	std::list<std::string> 	GetListCommand();

	uint16_t 				GetNumberOfRegisteredDevice();

	DevType_t 				GetDeviceType(std::string devID);

	char* 					GetCurrentStatusDevice(std::string devID);

	static void				RegisterCallback(Event_t eventType, CallbackFunction fcn, std::string szGatewayID);


	/**
	 * @brief ExecuteSimpleCommand
	 * @param devID string of device ID
	 * @param u16Cmd command in command list
	 * @param u16SubCmd sensor type:
	 * @return for sensor node: return 0xEFFF if error,
	 *                          return sensor value in case of succes
	 *         for valve and pump: return EFFF if error occur
	 *                      for command: get/set status return current status
	 *                      ACTUATOR_STATUS_ON/OFF of valve and pump
	 */
	static int16_t 			ExecuteSimpleCommand(std::string devID, uint16_t u16Cmd, uint16_t u16SubCmd);
	static int16_t 			ExecuteCommand(std::string szCommand);


};

} /* namespace Agriculture */

#endif /* CLSDEVICEMANAGER_H_ */
