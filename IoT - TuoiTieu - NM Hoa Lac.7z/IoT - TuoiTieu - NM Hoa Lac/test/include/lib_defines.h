/**
 * @defgroup lib Extra library
 * @brief Library for wapper os features: thread, semaphore, mutex ...<br/>
 * Common API for supported enviroment <br />
 * <ul>
 * <li>Linux (gcc compiler)</li>
 * <li>Windows (msvc compiler)</li>
 * </ul>
 *
 *
  */
#ifndef __LIB_DEFINES_H__
#define __LIB_DEFINES_H__

#define IN      ///< param is input
#define OUT     ///< param is output
#define INOUT   ///< param is input & output

#if defined(WIN32) && defined(_MSC_VER)
#define     COMPILER_MSC
#define     _WIN32
#define     WIN32_LEAN_AND_MEAN
#endif

#if defined(__gnu_linux__)
#define COMPILER_GCC
#endif

#if defined(__gnu_linux__)
#define FRAMEWORK_LINUX
#endif

#if defined(__MINGW32__)
#define COMPILER_GCC
#define _WIN32
#endif

#if defined(__ANDROID__)
#define FRAMEWORK_LINUX
#define COMPILER_GCC
#endif

#if defined(_WIN32)
#define snprintf sprintf_s
#define _open_file(f, n, m) fopen_s(&f, n, m)
#endif

#ifdef FRAMEWORK_LINUX
#define _open_file(f, n, m) f = fopen(n, m)
#endif

#if defined(LIB_LIBRARY)
    #ifdef FRAMEWORK_QT
        #  define LIBSHARED_EXPORT Q_DECL_EXPORT
    #endif
#else
    #ifdef FRAMEWORK_QT
        #  define LIBSHARED_EXPORT Q_DECL_IMPORT
    #endif
#endif

#endif
