/*
 * clsOnOffActuator.h
 *
 *  Created on: May 10, 2017
 *      Author: MANHBT
 */

#ifndef clsOnOffActuator_H_
#define clsOnOffActuator_H_

#include "IDevice.h"
#include <stdint.h>
#include <list>
#include <IComm.h>
#include <IIOController.h>
#include <mutex>
#include <unordered_map>
#include <clsTransSmartBus.h>
#include <clsTransRSP.h>

#include <clsRS485.h>
#include <CRC16.h>
#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"

namespace AHGSystems {

class clsOnOffActuator: public IDevice {
private:
	DevType_t 							m_u8DeviceType;
	std::string 						m_szDeviceID;
	std::string 						m_szDescription;
	std::string							m_szGatewayID;
	int16_t								m_i16Value;
	bool								m_bIsVisible;
	clsRS485*							m_pRS485;
	uint16_t							m_u16SMBusID;
	int8_t								m_i8PortNumber;
	std::mutex* 						m_pMutex;
	rapidjson::StringBuffer 			m_jsonBuilder;
//	std::list<CallbackFunction>			m_lstCallbackFunctions;
	std::unordered_map<CallbackFunction, void*> 	m_lstCallbackFunctions;
	std::unordered_map<CallbackFunction, void*> 	m_lstInternalCallbackFunctions;

public:
	clsOnOffActuator();
	virtual ~clsOnOffActuator();

	void 					SetController(clsRS485* pCtrl);
	void					SetHWAddress(uint16_t u16DeviceAddr, int8_t i8PortNumber);

	void 					SetDeviceID(std::string szDeviceID) override {m_szDeviceID = szDeviceID;}
	std::string 			GetDeviceID() override {return m_szDeviceID;}
	void 					SetDeviceDescription(std::string szDescription) override {m_szDescription = szDescription;}
	std::string 			GetDeviceDescription() override { return m_szDescription;}
	void					SetDevType(DevType_t type) override {m_u8DeviceType = type;}
	DevType_t				GetDevType() override {return m_u8DeviceType;}

	char*		 			GetCurrentStatus();// {return (char*)&m_i16Value;}
	void		 			RequestRelayBoxStatus();// {return (char*)&m_i16Value;}
	int16_t		 			ExecuteCommand(uint16_t u16Cmd, uint16_t u16SubCmd) override;
	uint8_t					UpdateValues(void *pvArgs);
	uint16_t 				ReadValue() override {return 0xEFFF;}
	bool					IsVisible() override {return m_bIsVisible;}
	void					SetVisible(bool visible) override {m_bIsVisible = visible;}
//	void					RegisterCallback(CallbackFunction fcn, std::string szGWID) override;// {if(fcn != nullptr) {m_lstCallbackFunctions.push_back(fcn);}}
	void					RegisterCallback(CallbackFunction fcn, std::string szGWID, void* pvParent) override;// {if(fcn != nullptr) {m_lstCallbackFunctions.push_back(fcn);}}
	void					RegisterInternalCallback(CallbackFunction fcn, std::string szGWID, void* pvParent);
};

} /* namespace AHGSystems */

#endif /* clsOnOffActuator_H_ */
