/*
 * clsSensor.h
 *
 *  Created on: May 10, 2017
 *      Author: MANHBT
 */

#ifndef CLSSENSOR_H_
#define CLSSENSOR_H_

#include "IDevice.h"
#include "IComm.h"
#include <ahg.h>
#include <thread>
#include <mutex>
#include <unordered_map>
#include <arpa/inet.h>
#include <clsRS485.h>
#include <iostream>
#include "config.h"
#include <list>
#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"
#include "SensorType.h"

namespace AHGSystems {

class clsSensor: public IDevice {
private:
	DevType_t 						m_u8SensorType;
	std::string 					m_szDeviceID;
	std::string 					m_szDescription;
	std::string						m_szGatewayID;

	clsRS485*						m_pConnHandler;
	int16_t							m_i16Value;
//	SensValue_t						m_sSensValue;
	bool							m_bIsVisible;
	uint16_t						m_u16RSPId;
//
//	std::mutex*						m_pUartMutex;
	std::mutex*						m_pSensorMutex;
//	std::list<CallbackFunction>		m_lstCallbackFunctions;
	std::unordered_map<CallbackFunction, void*> 	m_lstCallbackFunctions;
	std::unordered_map<CallbackFunction, void*> 	m_lstInternalCallbackFunctions;
    rapidjson::StringBuffer 		m_jsonBuilder;

#if (SENS_ERROR_LOG_ENABLE == ON)
	std::string 	m_szSensLogFileName;
#endif

public:
	clsSensor();

	virtual ~clsSensor();

	uint8_t 			UpdateValues(void *pvArgs) override;

	bool 				SetConnHandler(clsRS485* pHandler);// std::mutex* pUartMutex);

//	// Implement IDevice Functions
	void 				SetDeviceID(std::string szDeviceID) override {m_szDeviceID = szDeviceID;}
	std::string 		GetDeviceID() override {return m_szDeviceID;}

	void 				SetRSPId(uint16_t u16Id) {m_u16RSPId = u16Id;}
	uint16_t 			GetRSPId() {return m_u16RSPId;}

	void 				SetDeviceDescription(std::string szDescription) override {m_szDescription = szDescription;}
	std::string 		GetDeviceDescription() override {return m_szDescription;}

	void 				SetDevType(DevType_t u8DevType) override { m_u8SensorType = u8DevType;}
	DevType_t 			GetDevType() override {return m_u8SensorType;}

	uint16_t 			ReadValue() override {return 0xEFFF;}
	bool				IsVisible() override {return m_bIsVisible;}
	void				SetVisible(bool visible) override {m_bIsVisible = visible;}

	char*		 		GetCurrentStatus();
//	void				RegisterCallback(CallbackFunction fcn, std::string szGWID) override;
	void				RegisterCallback(CallbackFunction fcn, std::string szGWID, void* pvParent) override;
	void 				RegisterInternalCallback(CallbackFunction fcn, void* pvParent);
	int16_t 			ExecuteCommand(uint16_t u16Cmd, uint16_t u16SubCmd) override;
};

} /* namespace Agriculture */

#endif /* CLSSENSOR_H_ */
