/*
 * clsGPIOController.h
 *
 *  Created on: May 27, 2017
 *      Author: MANHBT
 */

#ifndef SRC_DEVICES_CONTROLLER_CLSGPIOCONTROLLER_H_
#define SRC_DEVICES_CONTROLLER_CLSGPIOCONTROLLER_H_

#include <IIOController.h>


namespace AHGSystems {

class clsGPIOController: public IIOController {

public:
	clsGPIOController();
	virtual ~clsGPIOController();

//	void		SetComm(IComm* pComm) override {return;}
	bool 		ReadPort(uint8_t u8PortNumber) override;
	bool 		WritePort(uint8_t u8PortNumber, bool bNewStatus) override;
	bool 		TogglePort(uint8_t u8PortNumber) override;
};

} /* namespace AHGSystems */

#endif /* SRC_DEVICES_CONTROLLER_CLSGPIOCONTROLLER_H_ */
