/*
 * IIOController.h
 *
 *  Created on: May 24, 2017
 *      Author: MANHBT
 */

#ifndef IIOCONTROLLER_H_
#define IIOCONTROLLER_H_
#include <string>
#include <stdint.h>
#include <ahg.h>
#include <IComm.h>

namespace AHGSystems {

class IIOController {
public:
	IIOController();
	virtual ~IIOController();

//	virtual void		SetComm(IComm* pComm) = 0;
	virtual bool 		ReadPort(uint8_t u8PortNumber) = 0;
	virtual bool 		WritePort(uint8_t u8PortNumber, bool bNewStatus) = 0;
	virtual bool 		TogglePort(uint8_t u8PortNumber) = 0;

//	virtual uint16_t 	ReadValue(uint8_t u8Channel) = 0;

};

} /* namespace Agriculture */

#endif /* IIOCONTROLLER_H_ */
