/*
 * SensorType.h
 *
 *  Created on: Jul 17, 2017
 *      Author: MANHBT
 */

#ifndef DEVICES_SENSORTYPE_H_
#define DEVICES_SENSORTYPE_H_

#ifdef __cplusplus
extern "C" {
#endif
////////////////////////////////////////// Include Files /////////////////////////////////////////////
//"air_temperature",
//"air_humidity",
//"soil_temperature",
//"soil_moisture",
//"light_ambient",
//"water_ec",
//"water_ph",
//"water_temperature",
//"water_level",
//"soil_ec",
//"soil_ph"

///////////////////////////////////// Constant Definitions ///////////////////////////////////////////
#define SENSOR_AIR_TEMPERATURE 		0x01
#define SENSOR_AIR_HUMIDITY			0x02
#define SENSOR_SOIL_TEMPERATURE		0x03
#define SENSOR_SOIL_MOISTURE		0x04
#define SENSOR_LIGHT_AMBIENT		0x05
#define SENSOR_WATER_EC				0x06
#define SENSOR_WATER_PH				0x07
#define SENSOR_WATER_TEMPERATURE	0x08
#define SENSOR_WATER_LEVEL			0x09
#define SENSOR_SOIL_EC				0x0A
#define SENSOR_SOIL_PH				0x0B
#define SENSOR_WATER_BUOY			0x0C
/////////////////////////////////////// Type Definitions /////////////////////////////////////////////

///////////////////////////// Macros (Inline Functions) Definitions //////////////////////////////////


///////////////////////////////////// Variable Definitions ///////////////////////////////////////////
extern const char* g_SensorKeyword[];

///////////////////////////////////// Function Prototypes ////////////////////////////////////////////

#ifdef __cplusplus
}
#endif


#endif /* DEVICES_SENSORTYPE_H_ */
