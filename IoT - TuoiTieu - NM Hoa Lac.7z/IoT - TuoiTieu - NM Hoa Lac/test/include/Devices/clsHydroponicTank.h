/*
 * clsHydroponicTank.h
 *
 *  Created on: Jul 24, 2017
 *      Author: MANHBT
 */

#ifndef DEVICES_CLSHYDROPONICTANK_H_
#define DEVICES_CLSHYDROPONICTANK_H_

#include <IDevice.h>
#include "IComm.h"
#include <ahg.h>
#include <thread>
#include <mutex>
#include <unordered_map>
#include <arpa/inet.h>
#include <clsRS485.h>
#include <iostream>
#include "config.h"
#include <list>

#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"
#include <devices.h>
#include <interfaces.h>
#include <processor.h>
#include <ctime>
#include <clsLogger.h>
#include <SimpleKalmanFilter.h>

namespace AHGSystems {
typedef enum E_WATER_STATUS
{
	WATER_EMPTY = 0,		// Nuoc can < 30%
	WATER_NORMAL = 1,			// Muc nuoc ok (30 - 80% binh)
	WATER_FULL = 2				// Nuoc day > 80%
} water_stat_t;

typedef	enum E_TANK_MODE
{
	TANK_MODE_INVALID = 0,
	TANK_MODE_AUTO = 1,
	TANK_MODE_MANUAL
} tank_mode_t;

typedef	enum E_TANK_SUBMODE
{
	TANK_SUB_MODE_INVALID = 0,
	TANK_SUB_MODE_YOUNG_TREE,
	TANK_SUB_MODE_NORMAL
} tank_sub_mode_t;


class clsHydroponicTank: public IDevice {

public:
	enum E_TANK_SUB_DEV_TYPE
		{
			TANK_DEV_BEGIN = 0xF0,
			TANK_SENSOR_NODE,
			TANK_W_PUMP_1,
			TANK_W_PUMP_2,
			TANK_DEV_END
		};


							clsHydroponicTank(std::string szDeviceID);
							~clsHydroponicTank();

	// Setup RSPID & SBUSID
	void					SetRSPHWAddress(uint8_t u8SubDevID, uint16_t u16RSPAddr);
	void					SetSBUSHWAddress(uint8_t u8SubDevID, uint16_t u16SBUSAddr, uint8_t u8PortNumber);

	void					Initialize(clsRS485* pRSPBus, clsRS485* pSMBus);
	std::unordered_map<std::string, int> GetListSupportedCommand();

	// IDevice Function
	void 					SetDeviceID(std::string szDeviceID) override;
	std::string 			GetDeviceID() override;
	void 					SetDeviceDescription(std::string szDescription) override;
	std::string 			GetDeviceDescription() override;
	void					SetDevType(DevType_t type) override;
	DevType_t				GetDevType() override;
	int16_t		 			ExecuteCommand(uint16_t u16Cmd, uint16_t u16SubCmd) override;
	int16_t 				ExecuteCommand(const char* szCmd);
	char*		 			GetCurrentStatus() override;;
	bool					IsVisible() override;
	void					SetVisible(bool visible) override;
	virtual	uint8_t			UpdateValues(void* pvArgs) override;
	uint16_t 				ReadValue() override;
	void					RegisterCallback(CallbackFunction fcn, std::string szGWID, void* pvParent) override;

	void 					ConfigureAutoManSwitch(uint8_t u8PinNumber);
	void 					ConfigureOnOffPump1(uint8_t u8PinNumber);
	void 					ConfigureStatePump1(uint8_t u8PinNumber);
	void 					ConfigureOnOffPump2(uint8_t u8PinNumber);
	void 					ConfigureStatePump2(uint8_t u8PinNumber);
private:

//#include "SimpleKalmanFilter.h"
	SimpleKalmanFilter* 				m_pECFilter;
	// IDevice members
	DevType_t 						m_eDevType;
	std::string 					m_szDeviceID;
	std::string 					m_szDescription;
	std::string						m_szGatewayID;

	bool							m_bIsVisible;
	uint16_t						m_u16RSPId;

	std::list<CallbackFunction>		m_lstOnStatusChangedCallbackFunctions;
//	std::list<CallbackFunction>		m_lstOnAlarmCallbackFunctions;
	std::unordered_map<std::string, int> m_lstSupportedCommand;
	std::mutex*						m_pMutex;
	std::mutex*						m_pJsonMutex;
	rapidjson::StringBuffer 		m_jsonBuilder;

	clsLogger* 						m_pLogger;
	clsLogger* 						m_pRawLogger;
	// Sensor value
//	bool							m_bIsRunning;				// Run/Stop
//	double_t						m_dWaterPH;					// PH Nuoc
//	double_t 						m_dWaterEC;					// EC Nuoc
//	double_t						m_dWaterTemperature;		// Nhiet do nuoc
//	water_stat_t					m_eWaterStatus;				// Muc nuoc

	struct
	{
		// schedule status
		tank_mode_t	eMode1 = TANK_MODE_MANUAL;
		tank_mode_t eMode2 = TANK_MODE_MANUAL;
		tank_mode_t eGlobalMode = TANK_MODE_AUTO;

//		tank_mode_t	eMode2 = TANK_MODE_MANUAL;
//		tank_sub_mode_t eSubmode2 = TANK_SUB_MODE_NORMAL;
//		tank_mode_t eGlobalMode2 = TANK_MODE_AUTO;

//		bool 	bCircualtorPumpEnable = true;
//		bool	bWaterFine = true;

		bool	bSensorConnected;
		bool	bSenEnable;

		float	dTempAir;
		float	dTempSoil;
		float	dHumiAir;
		float	dHumiSoil;
		// tanks components status

		bool	bOnOffPump1State;
		bool	bStatePump1State;
		bool	bErrorPump1State;
		bool	bOnOffPump2State;
		bool	bStatePump2State;
		bool	bErrorPump2State;

		bool	bIsNewStateChanged;
		bool	bIsMixing;
		std::chrono::time_point<std::chrono::_V2::system_clock, std::chrono::duration<long long int, std::ratio<1ll, 1000000000ll> > > tLastMixerRunPoint;// = std::chrono::system_clock::now();
		std::chrono::time_point<std::chrono::_V2::system_clock, std::chrono::duration<long long int, std::ratio<1ll, 1000000000ll> > > tLastCircularPumpSwitchPoint;// = std::chrono::system_clock::now();
		std::chrono::time_point<std::chrono::_V2::system_clock, std::chrono::duration<long long int, std::ratio<1ll, 1000000000ll> > > tLastSensorResponseTime;// = std::chrono::system_clock::now();
		std::chrono::time_point<std::chrono::_V2::system_clock, std::chrono::duration<long long int, std::ratio<1ll, 1000000000ll> > > tLastSensorRequestTime;// = std::chrono::system_clock::now();
	}m_tankStatus;

	struct
	{
		bool	bOnOffPump1State;
		bool	bOnOffPump2State;

		int		iCntOnOffPump1;
		int		iCntOnOffPump2;
	}m_tankStatus_request;

	// Range
	double_t						m_dHumiSoilThres;

	clsSensor*						m_pSensorNode;			// RSP Sensor node -- RSP id

	clsOnOffActuator* 				m_pWaterPump1;			// Bom nuoc tuoi khu vuc 1
	clsOnOffActuator* 				m_pWaterPump2;			// Bom nuoc tuoi khu vuc 2

	clsRS485*						m_pRSPConnHandler;
	clsRS485*						m_pSBusConnHandler;

//	Thread*							m_pMainThread;

	mraa::Gpio*						m_pTankModeSwitch;

	mraa::Gpio*						m_pTankStatePump1;
	mraa::Gpio*						m_pTankStatePump2;
	mraa::Gpio*						m_pTankOnOffPump1;
	mraa::Gpio*						m_pTankOnOffPump2;

	pthread_t 						m_mainThreadHandle;
	pthread_t 						m_SensorUpdateThread;
	pthread_t						m_TankSafeThread;


	void 							SetHumiSoilThres(double_t dHumi);
	void							TankStop(int c);
	void 							TankRun(int c);

	char* 							GenerateJson(Event_t event_type);

	void							SensorThreadProc(void *pArgs, bool *bIsTerminate);
	void							TankThreadProc(void *pArgs, bool *bIsTerminate);
	void 							TankSafeThreadProc(void *pArgs, bool *bIsTerminate);

	int 							processSensorEvent(std::string szDeviceID, char* pcStatus);
	int 							processActuatorEvent(std::string szDeviceID, char* pcStatus);
	void 							processModeChangedEvent(void *pvParent);

	static int 						onActuatorStatusChanged(std::string szDeviceID, char* pcStatus, void *pvParent);
	static int 						onSensorStatusChanged(std::string szDeviceID, char* pcStatus, void *pvParent);
	static void						onModeChanged(void *pvParent);

	int								GetSwitchValue();

	int 							GetOnOffPumpValue1();
	int 							GetStatePumpValue1();

	int 							GetOnOffPumpValue2();
	int 							GetStatePumpValue2();

	static void 					onWaterFloatStatusChanged(void* pvParent);
	void							processWaterFloatStatusChanged(void* pvParent);

	int 							AutomaticMonitoring(int c);
	void 							DeviceControl(clsOnOffActuator* pDev, bool bOnOff);

};

} /* namespace AHGSystems */

#endif /* DEVICES_CLSHYDROPONICTANK_H_ */
