/*
 * IDevice.h
 *
 *  Created on: May 10, 2017
 *      Author: MANHBT
 */

#ifndef IDEVICE_H_
#define IDEVICE_H_
#include <string>
#include <stdint.h>
//#include <ICommand.h>
#include <ahg.h>
#include <unordered_map>

namespace AHGSystems {

class IDevice {
public:
	IDevice();
	virtual ~IDevice();

	virtual void 					SetDeviceID(std::string szDeviceID) = 0;
	virtual std::string 			GetDeviceID() = 0;

	virtual void 					SetDeviceDescription(std::string szDescription) = 0;
	virtual std::string 			GetDeviceDescription() = 0;
	virtual void					SetDevType(DevType_t type) = 0;
	virtual DevType_t				GetDevType() = 0;

//	virtual std::unordered_map<std::string, int> GetListSupportedCommand() = 0;
	virtual int16_t		 			ExecuteCommand(uint16_t u16Cmd, uint16_t u16SubCmd) = 0;
	virtual char*		 			GetCurrentStatus() =0;
	virtual bool					IsVisible() = 0;
	virtual void					SetVisible(bool visible) = 0;

	virtual	uint8_t					UpdateValues(void* pvArgs) = 0;
	virtual uint16_t 				ReadValue() = 0;

	virtual void					RegisterCallback(CallbackFunction fcn, std::string szGWID, void *pvParent) = 0;
	virtual int16_t		 			ExecuteCommand(const char* szCmd);
};

} /* namespace Agriculture */

#endif /* IDEVICE_H_ */
