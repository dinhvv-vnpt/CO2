/*
 * config.h
 *
 *  Created on: May 25, 2017
 *      Author: MANHBT
 */

#ifndef SRC_CONFIG_H_
#define SRC_CONFIG_H_


/**
 * GLOBAL Configurations
 */
#define TANK_DEBUG				0

// Device manager config
#define SENS_CHECK_ITER_PERIOD 	2
#define DEVMAN_DEBUG_ENABLE		OFF

// clsOnOffActuator config
#define 	ACT_DEBUG_ENABLE	OFF



// clsSensor - Sensor node configurations
#define 	SENS_DEBUG_ENABLE			OFF
#define 	SENS_ERROR_LOG_ENABLE		OFF			// Enable/Disable system log for Sensor node read timed out


// SmartBus Relay controller config
#define SMARTBUS_RELAY_MAXIMUM_PORT		8
#define SMARTBUS_DEBUG_ENABLE			OFF


// RS485 Bus #1
#define COMM_RS485_BUS1_DE_PIN_NUM 	71
#define COMM_RS485_BUS1_UART_DEV_NAME 	"/dev/ttyO1"
#define COMM_RS485_BUS1_BAUD		9600
#define COMM_RS485_BUS1_DATABIT		8
#define COMM_RS485_BUS1_STOPBIT		1
#define COMM_RS485_BUS1_PARITY		mraa::UART_PARITY_EVEN
#define COMM_RS485_BUS1_HWFLOWCTRL	OFF

// RS485 Bus #2
#define COMM_RS485_BUS2_DE_PIN_NUM 	69
#define COMM_RS485_BUS2_UART_DEV_NAME 	"/dev/ttyO2"
#define COMM_RS485_BUS2_BAUD		9600
#define COMM_RS485_BUS2_DATABIT		8
#define COMM_RS485_BUS2_STOPBIT		1
#define COMM_RS485_BUS2_PARITY		mraa::UART_PARITY_EVEN
#define COMM_RS485_BUS2_HWFLOWCTRL	OFF

#define	COMM_RS485_RESPONSE_TIMEOUT_MS	150		// RS485 Rx Timeout (m.sec)

#define	COMM_RS485_TX_QUEUE_SIZE	128			// RS485 Tx Queue size


#define	DEVMAN_SENSOR_UPDATE_INTERVAL_SEC		20
#define DEVMAN_SENSOR_TIMEOUT_SEC				(5 * DEVMAN_SENSOR_UPDATE_INTERVAL_SEC)		// Sensor node Timeout (sec)
#define DEVMAN_FERTILIZER_GAP_MINUTE			5

#define BUTTON_PRESSED_DETECT_TIME_MS	150		// Button Detect timeout (m.sec)

#define CFG_AIR_TEMP_MAX		50
#define CFG_AIR_TEMP_MIN		5

#define CFG_AIR_HUMID_MAX		100
#define CFG_AIR_HUMID_MIN		10

#define CFG_SOIL_TEMP_MAX		50
#define CFG_SOIL_TEMP_MIN		5

#define CFG_SOIL_HUMID_MAX		100
#define CFG_SOIL_HUMID_MIN		10

#define CFG_AIR_HUMID_COEF		0.814539614
#define CFG_AIR_HUMID_OFFSET	-0.284961828



/**
 * AUTO/MAN GPIO Pin number definitions
 */
//DI1  - AT1
#define DI1		12
#define DI2		11
#define DI3		14
#define DI4		15
#define DI5		16
#define DI6		17
#define DI7		18
#define DI8		26
#define DI9		58
#define DI10	61
#define DI11	73
#define DI12	88

#define DEVMAN_MODE_SELECT_PIN						DI1		// Tank 1 auto/man pin number 	(DI8)

#if (TANK_DEBUG == 0)
#define	DEVMAN_ONOFF_PUMP_1_PIN						DI8			// Phan hoi On/Off bom 1
#define	DEVMAN_ONOFF_PUMP_2_PIN						DI9			// Phan hoi On/Off bom 2
#define	DEVMAN_STATE_PUMP_1_PIN						DI12		// Phan hoi OverLoad bom 1
#define	DEVMAN_STATE_PUMP_2_PIN						DI12		// Phan hoi OverLoad bom 2
#endif


// TANKS
#define DEVMAN_DEV_ID						"TUOI-TIEU-HOA-LAC"

// [manhbt] tank components ID
#define DEVMAN_SENSOR_NODE					"TankSensorNode"

#define DEVMAN_PUMP1						"Pump1"
#define DEVMAN_PUMP2						"Pump2"

// Tank commands
#define SCMD_SET_HUMI_SOIL_THRES			"SetHumiSoilThres"
#define SCMD_RUN_1							"Run1"
#define SCMD_RUN_2							"Run2"
#define SCMD_STOP_1							"Stop1"
#define SCMD_STOP_2 						"Stop2"
#define SCMD_GET_STATUS						"GetStatus"

// Command for TurnOn-TurnOff devices
#define SCMD_TURN_ON                    "On"
#define	SCMD_TURN_OFF                   "Off"

// HW Address of Tank1 components
#define	DEVMAN_SENSOR_NODE_ADDRESS		0x0101

#define DEVMAN_W_PUMP_1_PORT				1				// RL1.1
#define DEVMAN_W_PUMP_1_ADDRESS			0x0101
#define DEVMAN_W_PUMP_2_PORT				2				// RL1.2
#define DEVMAN_W_PUMP_2_ADDRESS			0x0101


#endif /* SRC_CONFIG_H_ */
