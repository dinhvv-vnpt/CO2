/*
 * process_co2.cpp
 *
 *  Created on: Oct 14, 2017
 *      Author: dinht
 */
#include "clsCO2.h"
#include <Debug.h>
#include <config.h>

#include <CRC16.h>


#include <clsSMBusProcessor.h>
#include <clsRSPProcessor.h>
#include <arpa/inet.h>

namespace AHGSystems {
#define RS485_DEBUG_ENABLE	OFF

clsCO2::clsCO2(uint8_t u8BusNumber)
{
	m_u32SendingInterval = COMM_RS485_RESPONSE_TIMEOUT_MS;
		m_pLogger = nullptr;
		bIsSearchingHeader	= TRUE;
		pucRecvFrame[258] = {0};
		u8RecvDataCount		= 0;
		u8ProtocType		= PROTO_TYPE_UNDEFINED;	// Protocol type: 0-Undefined, 1-SMBUS, 2-RSP

		m_pMainThread = nullptr;
		m_pRxThread = nullptr;


		m_u8BusNumber = u8BusNumber;
		m_pRS485Mutex = new std::mutex();
		m_pRS485RxBufferMutex = new std::mutex();
		m_pRS485TxBufferMutex = new std::mutex();

		m_sRxRingBuffer = new RingBuffer2();

		m_pRS485TxQueue = new std::queue<ProtoFrame_t>();

		if(m_u8BusNumber == 1)
		{
			try {
				 m_pRS485UartHandler = new mraa::Uart(COMM_RS485_BUS1_UART_DEV_NAME);
			} catch (std::exception& e) {
				LREP("Error while setting up raw UART, do you have a uart?");
				std::terminate();
			}

			m_pRS485UartHandler->setBaudRate(COMM_RS485_BUS1_BAUD);

			mraa::Result res = m_pRS485UartHandler->setMode(COMM_RS485_BUS1_DATABIT, mraa::UART_PARITY_EVEN, COMM_RS485_BUS1_STOPBIT);
			if(res != mraa::SUCCESS)
				LREP("failed to set up uart mode even");
			m_pRS485UartHandler->setFlowcontrol(false, false);

			m_pRS485DEPin = new mraa::Gpio(COMM_RS485_BUS1_DE_PIN_NUM);
			m_pRS485DEPin->dir(mraa::DIR_OUT);
			m_pRS485DEPin->mode(mraa::MODE_PULLUP);
		}
		else if (m_u8BusNumber == 2)
		{
			try {
				 m_pRS485UartHandler = new mraa::Uart(COMM_RS485_BUS2_UART_DEV_NAME);
			} catch (std::exception& e) {
				LREP("Error while setting up raw UART, do you have a uart?");
				std::terminate();
			}

			m_pRS485UartHandler->setBaudRate(COMM_RS485_BUS2_BAUD);

			mraa::Result res = m_pRS485UartHandler->setMode(COMM_RS485_BUS2_DATABIT, mraa::UART_PARITY_NONE, COMM_RS485_BUS2_STOPBIT);
			if(res != mraa::SUCCESS)
				LREP("failed to set up uart mode even");
			m_pRS485UartHandler->setFlowcontrol(false, false);

			m_pRS485DEPin = new mraa::Gpio(COMM_RS485_BUS2_DE_PIN_NUM);
			m_pRS485DEPin->dir(mraa::DIR_OUT);
			m_pRS485DEPin->mode(mraa::MODE_PULLUP);
		}
		else
		{
			LREP_ERROR("Invalid RS485 Bus Number #%d!", m_u8BusNumber);
			return;
		}

		if (m_pRS485UartHandler->setFlowcontrol(false, false) != mraa::SUCCESS) {
			LREP_ERROR("Error setting flow control UART");
		}

		m_pRS485UartHandler->setTimeout(10, 100, 1);
		m_pRS485UartHandler->setNonBlocking(true);

		ThreadFuncPtr tMain = (ThreadFuncPtr)&clsCO2::MainProcessThread;
		PthreadPtr   pMain = *(PthreadPtr*)&tMain;
		pthread_t    tMainid;
		if (pthread_create(&tMainid, 0, pMain, this) == 0)
		{
		  pthread_detach(tMainid);
		}
}

clsCO2::~clsCO2() {
	delete m_pRS485Mutex ;
	delete m_pRS485RxBufferMutex;
	delete m_pRS485TxBufferMutex;

	delete m_sRxRingBuffer;

	delete m_pRS485TxQueue;
	delete m_pRS485UartHandler;

	delete m_pRS485DEPin;
}

BOOL 	clsCO2::SendData(ProtoFrame_t sFrame)
{
	m_pRS485TxBufferMutex->lock();
	if(m_pRS485TxQueue->size() <= COMM_RS485_TX_QUEUE_SIZE)
		m_pRS485TxQueue->push(sFrame);
	m_pRS485TxBufferMutex->unlock();
	return TRUE;
}

void clsCO2::GetCO2() //Thread (10)
{
	int readLen;
	int total_rcv_bytes=0;
	char xC;
	uint8_t rcv_buffer[15];
	float temp=0,value_co2=0;
	//B1: Send Cmd -> CO2
	uint8_t data[8];
	data[0]=0x01;
	data[1]=0x03;
	data[2]=0x01;
	data[3]=0x02;
	data[4]=0x00;
	data[5]=0x02;
	data[6]=0x64;
	data[7]=0x37;
	ProtoFrame_t frame;
	frame.len = sizeof(data);
	frame.data = new uint8_t[frame.len];
	memcpy(frame.data, data, frame.len);
	m_pRS485DEPin->write(1);

	SendData(frame);
	m_pRS485DEPin->write(0);
	while (1)
	{
			if(m_pRS485UartHandler->dataAvailable(200))
			{
			 readLen = m_pRS485UartHandler->read(&xC, 1);
			 if (readLen == 1)
			 {
				 rcv_buffer[total_rcv_bytes] = xC;
				 total_rcv_bytes++;
				 LREP_RAW(" %.2X ", (0xFF & xC));
 			 }

			}
			else
			{
			break;
			}
// CHo nay anh xu ly du lieu nhan duoc, luu cac thong tin doc duoc vao 1 struct

	//B2: Read Data CO2
	//B3: Get Json
	//B4: Send Json

//			Với lại anh viết tương tự như thằng clsSensor của em ạ, phải impliment đầy đủ các hàm của IDevice.h
//			Sau đó trong deviceManager anh khai báo 1 cái class CO2sensor này

}
// filter data
	if(total_rcv_bytes>=9)
	{
	switch (total_rcv_bytes)
	{
	case 9:
		if((rcv_buffer[0]==0x01)&&(rcv_buffer[1]==0x03)&&(rcv_buffer[2]==0x04))
		{
		temp=rcv_buffer[3]*256+	rcv_buffer[4];
		value_co2=rcv_buffer[5]+rcv_buffer[6];
		}
	break;
	case 10:
		if((rcv_buffer[1]==0x01)&&(rcv_buffer[2]==0x03)&&(rcv_buffer[3]==0x04))
		{
		temp=rcv_buffer[4]*256+	rcv_buffer[5];
		value_co2=rcv_buffer[6]+rcv_buffer[7];
		}
	break;
	}

}
}
void	clsCO2::MainProcessThread(void *pArgs, bool *bIsTerminate)
{
	for(;;)
	{
		GetCO2();
		std::this_thread::sleep_for(std::chrono::seconds(5));
	}
}

}


















