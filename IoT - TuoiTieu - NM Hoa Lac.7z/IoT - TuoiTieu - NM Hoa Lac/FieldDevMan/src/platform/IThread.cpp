#include "IThread.h"
#include <stdlib.h>

IThread::IThread(FXN fxn)
{
    m_bIsRunning        = false;
    m_bIsTerminate      = false;
    m_fxnInfo.fxn       = fxn;
    m_fxnInfo.pInput    = NULL;
}

IThread::~IThread()
{

}

bool IThread::IsRunning()
{
    return m_bIsRunning;
}
