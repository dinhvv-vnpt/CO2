#include "Platform_Thread.h"
#include <unistd.h>
#include "../lib_defines.h"

Platform_Thread::Platform_Thread(FXN fxn) :
    IThread(fxn)
{
    m_obj = NULL;
}

Platform_Thread::~Platform_Thread()
{
    Stop();
}

int Platform_Thread::Start(void* pInput)
{
    int ret = -1;
    if(!this->IsRunning())
    {
        this->m_fxnInfo.pInput = pInput;
        this->m_bIsTerminate = false;
        m_obj = pInput;
        pthread_create(&m_threadHandle, NULL, Platform_Thread_run, this);
        ret = 0;
    }
    return ret;
}

int Platform_Thread::Stop(int timeout)
{
    if(m_bIsRunning){
        this->m_bIsTerminate = true;
        pthread_join(m_threadHandle, NULL);
    }
    return 0;
}

void* Platform_Thread_run(void *param)
{
    Platform_Thread *inst = (Platform_Thread*)param;
    inst->m_bIsRunning = true;
    if(inst->m_fxnInfo.fxn)
    {
        inst->m_fxnInfo.fxn(inst->m_fxnInfo.pInput, &inst->m_bIsTerminate);
    }
    inst->m_bIsRunning = false;
    return NULL;
}
#include <sys/select.h>
void Platform_Thread::SleepMs(int ms)
{
    usleep(ms * 1000);
}

void Platform_Thread::SleepUs(int us)
{
    usleep(us);
}
