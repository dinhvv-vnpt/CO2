#include <Thread.h>


Thread::Thread(FXN fxn) :
    Platform_Thread(fxn)
{

}
Thread::~Thread()
{

}


