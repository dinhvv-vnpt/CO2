#include "Debug.h"
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <stdint.h>
#include <ctype.h>

using namespace lib;
void debug_nothing(const char* sz, ...){}
debug_callback Debug::s_callback = NULL;
void* Debug::s_obj = NULL;
Debug::Debug(){
}

Debug::~Debug()
{

}

void Debug::SetCallback(debug_callback fxn, void* obj)
{
    s_callback = fxn;
    s_obj = obj;
}

void Debug::_PRINT(const char* string, ...)
{
    char szBuffer[2048];
    va_list arglist;
    va_start(arglist, string);
    memset(szBuffer, 0, 2048);
#ifdef _MSC_VER
    vsprintf_s(szBuffer, 2047, string, arglist);
#elif defined(__GNUC__)
    vsprintf(szBuffer, string, arglist);
#endif
    if(s_callback)
        s_callback(szBuffer, s_obj);
    else
    {
        printf("%s", szBuffer);fflush(stdout);
    }
}

void Debug::_DUMP(const void* data, int len, const char* string, ...)
{
    uint8_t* p = (uint8_t*)data;
    uint8_t  buffer[16];
    int iLen;

    _PRINT("%s %u bytes\n", string, len);
    while (len > 0)
    {
        iLen = (len > 16) ? 16 : len;
        memset(buffer, 0, 16);
        memcpy(buffer, p, iLen);
        for (int i = 0; i < 16; i++)
        {
            if (i < iLen)
                _PRINT("%02X ", buffer[i]);
            else
                _PRINT("   ");
        }
        _PRINT("\t");
        for (int i = 0; i < 16; i++)
        {
            if (i < iLen)
            {
                if (isprint(buffer[i]))
                    _PRINT("%c", (char)buffer[i]);
                else
                    _PRINT(".");
            }
            else
                _PRINT(" ");
        }
        _PRINT("\n");
        len -= iLen;
        p += iLen;
    }
    //_PRINT("\n");
}


