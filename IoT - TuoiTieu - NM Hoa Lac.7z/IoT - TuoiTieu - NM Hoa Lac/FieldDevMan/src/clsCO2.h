/*
 * process_co2.h
 *
 *  Created on: Oct 14, 2017
 *      Author: dinht
 */

#ifndef SRC_CLSCO2_H_
#define SRC_CLSCO2_H_

#include <stdint.h>
#include <thread>
#include <mraa.hpp>
#include <ahg.h>
#include <mutex>
#include <algorithm>
#include <iostream>
#include <list>
#include <queue>
#include <clsLogger.h>
#include <Thread.h>
//#include <RingBuffer.h>
#include <RingBuffer2.h>

#include <clsTransSmartBus.h>
#include <clsTransRSP.h>
namespace AHGSystems {


class clsCO2 {

	void 	MainProcessThread(void *pArgs, bool *bIsTerminate);

	void 	RxProcessThread(void *pArgs, bool *bIsTerminate);

	void 	RxRingBuffLock();
	void 	RxRingBufferUnlock();

	void 	ProcessReceivedData();

	void 	GetCO2();

	/**
	 * add logger member
	 */
	clsLogger*					m_pLogger;

	mraa::Gpio*					m_pRS485DEPin;
	mraa::Uart* 				m_pRS485UartHandler;

	std::mutex*					m_pRS485Mutex;

	// RxRingBuffer need to send
	std::mutex*					m_pRS485RxBufferMutex;
	RingBuffer2*					m_sRxRingBuffer;

	// TxQueue of ProtocFrame_t need to send
	std::mutex*					m_pRS485TxBufferMutex;
	std::queue<ProtoFrame_t>* 	m_pRS485TxQueue;


	 uint8_t 					m_u8BusNumber;

	 uint32_t					m_u32SendingInterval; // Sending time interval (in miliseconds)

	 Thread*					m_pMainThread;
	 Thread*					m_pRxThread;

	BOOL			bIsSearchingHeader	= TRUE;
	uint8_t			pucRecvFrame[258] = {0};
	uint8_t			u8RecvDataCount		= 0;
	ProtocType_t	u8ProtocType		= PROTO_TYPE_UNDEFINED;	// Protocol type: 0-Undefined, 1-SMBUS, 2-RSP

public:

	clsCO2(uint8_t);
	virtual ~clsCO2();

//	static void * InternalThreadEntryFunc(void * This) {((MyThreadClass *)This)->InternalThreadEntry(); return NULL;}


	void 		Initialize();

	void 		SetBaudrate(uint32_t u32Baud);

	uint8_t		SetMode(uint8_t u8DataBit, mraa::UartParity parity, uint8_t u8StopBit);

	void 		SetSendingIntervalMs(uint32_t u32Miliseconds);

	BOOL 		SendData(ProtoFrame_t sFrame);

};

} /* namespace AHGSystems */


#endif /* SRC_CLSCO2_H_ */
