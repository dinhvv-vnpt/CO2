/*
 * clsRSPProcessor.cpp
 *
 *  Created on: May 30, 2017
 *      Author: buiti
 */

#include <Processor/clsRSPProcessor.h>
#include <Debug.h>
#include <clsTransRSP.h>
#include <CRC8.h>
#include <CRC16.h>
#include <arpa/inet.h>

namespace AHGSystems {
clsRSPProcessor*	m_pRSPInstance;
std::list<std::shared_ptr<IDevice>>	m_lstRSPDevice;

clsRSPProcessor::clsRSPProcessor() {
	//
	m_lstRSPDevice.clear();
}

clsRSPProcessor::~clsRSPProcessor() {
	//
}


clsRSPProcessor* clsRSPProcessor::Instance()
{
	if(m_pRSPInstance == nullptr)
		m_pRSPInstance = new clsRSPProcessor();

	return m_pRSPInstance;
}


void clsRSPProcessor::RegisterDevice(std::shared_ptr<IDevice> pDevice)
{
	m_lstRSPDevice.push_back(pDevice);
}

void clsRSPProcessor::Process(void* pvFrame)
{
//	TransRSP::RSPFrame_t *pFrame = (TransRSP::RSPFrame_t*)pvFrame;

	uint8_t* pu8Frame = (uint8_t*)pvFrame;

	if(pu8Frame == nullptr)
		LREP("Invalid Frame");
//
//	LREP("\r\n[Firmware][clsRSPProcessor] Decoded frame: len: %.4x, flags: %.2x, seq: %.2x, dst: %.4x, src: %.4x, crch: %.2x, crcd: %.4x",
//		pFrame->dlen,
//		pFrame->flags,
//		pFrame->seq,
//		pFrame->dstaddr,
//		pFrame->srcaddr,
//		pFrame->crch,
//		pFrame->crcd);

	uint8_t u8CRCH = CalCRC8(&pu8Frame[RSP_FRM_IDX_DLEN - RSP_FRM_SOF_SIZE ], 8 );
	if(u8CRCH != pu8Frame[RSP_FRM_IDX_CRCH - RSP_FRM_SOF_SIZE])
	{
		LREP("[Firmware][clsRSPProcessor::Process] Invalid CRC_H, cal: %.2x, get: %.2x",
				u8CRCH,
				pu8Frame[RSP_FRM_IDX_CRCH - RSP_FRM_SOF_SIZE]
//				pFrame->crch
		);
		return;
	}


	uint16_t u16Dlen = htons(*(uint16_t*)&pu8Frame[RSP_FRM_IDX_DLEN- RSP_FRM_SOF_SIZE]);
//	LREP("[Firmware][clsRSPProcessor::Process] dlen: %d",	u16Dlen);
	uint16_t u16CRCD = CalculateCRC16(&pu8Frame[RSP_FRM_IDX_CRCH - RSP_FRM_SOF_SIZE], u16Dlen + 1);
	if (u16CRCD != htons(*(uint16_t*)&pu8Frame[RSP_FRM_IDX_DATA0 - RSP_FRM_SOF_SIZE + u16Dlen]))
	{
		LREP("[Firmware][clsRSPProcessor::Process] Invalid CRC_D, cal: %.4x, get: %.4x",
				u16CRCD,
				htons(*(uint16_t*)&pu8Frame[RSP_FRM_IDX_DATA0 - RSP_FRM_SOF_SIZE + u16Dlen])
				);
//		delete pu8Frame;
		return;
	}

	// Parse frame to the Corresponding Device
	for (auto itr : m_lstRSPDevice)
	{
		itr->UpdateValues(pvFrame);
	}
//	delete pu8Frame;
}

} /* namespace AHGSystems */
