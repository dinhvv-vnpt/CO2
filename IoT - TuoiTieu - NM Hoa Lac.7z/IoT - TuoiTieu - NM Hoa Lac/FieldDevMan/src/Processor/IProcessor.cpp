/*
 * IProcessor.cpp
 *
 *  Created on: May 30, 2017
 *      Author: buiti
 */

#include <Processor/IProcessor.h>

namespace AHGSystems {

IProcessor::IProcessor() {
	//

}

IProcessor::~IProcessor() {
	//
}

} /* namespace AHGSystems */
