/*
 * clsSMBusProcessor.cpp
 *
 *  Created on: May 30, 2017
 *      Author: buiti
 */

#include <Processor/clsSMBusProcessor.h>
#include <Debug.h>
#include <clsTransSmartBus.h>

namespace AHGSystems {

clsSMBusProcessor*	m_pSMBusInstance;
std::list<std::shared_ptr<IDevice>>	m_lstSMBusDevice;

clsSMBusProcessor::clsSMBusProcessor() {
	//
	m_lstSMBusDevice.clear();
}

clsSMBusProcessor::~clsSMBusProcessor() {
	//
}


clsSMBusProcessor* clsSMBusProcessor::Instance()
{
	if(m_pSMBusInstance == nullptr)
		m_pSMBusInstance = new clsSMBusProcessor();

	return m_pSMBusInstance;
}


void clsSMBusProcessor::RegisterDevice(std::shared_ptr<IDevice> pDevice)
{
	m_lstSMBusDevice.push_back(pDevice);
//	LREP("m_lstSMBusDevice count: %d", m_lstSMBusDevice.size());
}

void clsSMBusProcessor::Process(void* pvFrame)
{
	if(pvFrame == nullptr)
	{
		LREP("Invalid Frame");
		return;
	}

//	TransSmartBus::SMBusFrame_t *pFrame = (TransSmartBus::SMBusFrame_t*)pvFrame;
//	if(pFrame == nullptr)
//		LREP("Invalid Frame");

//	LREP("\r\n[clsSMBusProcessor] Decoded frame: len: %.2x, src: %.2x%.2x, type: %.4x, op: %.4x, dst: %.2x%.2x, crc: %.4x",
//		pFrame->dlen,
//		pFrame->src_subid, pFrame->src_devid,
//		pFrame->devtype,
//		pFrame->opcode,
//		pFrame->dst_subid, pFrame->dst_devid,
//		pFrame->crc);

	// TODO: Check CRC

	// TODO: Decode Frame for Address, control

	// Parse frame to the Corresponding Device
	for (auto itr : m_lstSMBusDevice)
	{
		itr->UpdateValues(pvFrame);

	}
//	delete pFrame;
}


} /* namespace AHGSystems */
