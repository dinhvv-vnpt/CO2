/*
 * clsRS485.cpp
 *
 *  Created on: May 28, 2017
 *      Author: buiti
 */

#include <clsRS485.h>
#include <Debug.h>
#include <config.h>

#include <CRC16.h>


#include <clsSMBusProcessor.h>
#include <clsRSPProcessor.h>
#include <arpa/inet.h>

namespace AHGSystems {
#define RS485_DEBUG_ENABLE	OFF

//mraa::Gpio*					m_pRS485DEPin;
//mraa::Uart* 				m_pRS485UartHandler;
//
//std::mutex*					m_pRS485Mutex;
//
//// RxRingBuffer need to send
//std::mutex*					m_pRS485RxBufferMutex;
//RingBuffer*					m_sRxRingBuffer;
//
//// TxQueue of ProtocFrame_t need to send
//std::mutex*					m_pRS485TxBufferMutex;
//std::queue<ProtoFrame_t>* 	m_pRS485TxQueue;


clsRS485::clsRS485(uint8_t u8BusNumber) {

	m_u32SendingInterval = COMM_RS485_RESPONSE_TIMEOUT_MS;
	m_pLogger = nullptr;
	bIsSearchingHeader	= TRUE;
	pucRecvFrame[258] = {0};
	u8RecvDataCount		= 0;
	u8ProtocType		= PROTO_TYPE_UNDEFINED;	// Protocol type: 0-Undefined, 1-SMBUS, 2-RSP

	m_pMainThread = nullptr;
	m_pRxThread = nullptr;


	m_u8BusNumber = u8BusNumber;
	m_pRS485Mutex = new std::mutex();
	m_pRS485RxBufferMutex = new std::mutex();
	m_pRS485TxBufferMutex = new std::mutex();

	m_sRxRingBuffer = new RingBuffer2();

	m_pRS485TxQueue = new std::queue<ProtoFrame_t>();

	if(m_u8BusNumber == 1)
	{
		try {
			 m_pRS485UartHandler = new mraa::Uart(COMM_RS485_BUS1_UART_DEV_NAME);
		} catch (std::exception& e) {
			LREP("Error while setting up raw UART, do you have a uart?");
			std::terminate();
		}

		m_pRS485UartHandler->setBaudRate(COMM_RS485_BUS1_BAUD);

		mraa::Result res = m_pRS485UartHandler->setMode(COMM_RS485_BUS1_DATABIT, mraa::UART_PARITY_EVEN, COMM_RS485_BUS1_STOPBIT);
		if(res != mraa::SUCCESS)
			LREP("failed to set up uart mode even");
		m_pRS485UartHandler->setFlowcontrol(false, false);

		m_pRS485DEPin = new mraa::Gpio(COMM_RS485_BUS1_DE_PIN_NUM);
		m_pRS485DEPin->dir(mraa::DIR_OUT);
		m_pRS485DEPin->mode(mraa::MODE_PULLUP);
	}
	else if (m_u8BusNumber == 2)
	{
		try {
			 m_pRS485UartHandler = new mraa::Uart(COMM_RS485_BUS2_UART_DEV_NAME);
		} catch (std::exception& e) {
			LREP("Error while setting up raw UART, do you have a uart?");
			std::terminate();
		}

		m_pRS485UartHandler->setBaudRate(COMM_RS485_BUS2_BAUD);

		mraa::Result res = m_pRS485UartHandler->setMode(COMM_RS485_BUS2_DATABIT, mraa::UART_PARITY_EVEN, COMM_RS485_BUS2_STOPBIT);
		if(res != mraa::SUCCESS)
			LREP("failed to set up uart mode even");
		m_pRS485UartHandler->setFlowcontrol(false, false);

		m_pRS485DEPin = new mraa::Gpio(COMM_RS485_BUS2_DE_PIN_NUM);
		m_pRS485DEPin->dir(mraa::DIR_OUT);
		m_pRS485DEPin->mode(mraa::MODE_PULLUP);
	}
	else
	{
		LREP_ERROR("Invalid RS485 Bus Number #%d!", m_u8BusNumber);
		return;
	}

	if (m_pRS485UartHandler->setFlowcontrol(false, false) != mraa::SUCCESS) {
		LREP_ERROR("Error setting flow control UART");
	}

	m_pRS485UartHandler->setTimeout(10, 100, 1);
	m_pRS485UartHandler->setNonBlocking(true);

}

void clsRS485::Initialize()
{
	char szLogFileName[128];
	sprintf(szLogFileName, "delco_rs485_bus_%d.log", m_u8BusNumber);
	m_pLogger = new clsLogger(szLogFileName);
	m_pLogger->LogInfo("*************** RS485 BUS %d STARTED **************", m_u8BusNumber);

	m_sRxRingBuffer->BufferInit(4096, m_pRS485RxBufferMutex);

//	m_sRxRingBuffer->BufferInit(1024, nullptr, nullptr);
#if 1
	ThreadFuncPtr tMain = (ThreadFuncPtr)&clsRS485::MainProcessThread;
	PthreadPtr   pMain = *(PthreadPtr*)&tMain;
	pthread_t    tMainid;
	if (pthread_create(&tMainid, 0, pMain, this) == 0)
	{
	  pthread_detach(tMainid);
	}

	ThreadFuncPtr tRx = (ThreadFuncPtr)&clsRS485::RxProcessThread;
	PthreadPtr   pRx = *(PthreadPtr*)&tRx;
	pthread_t    tRxid;
	if (pthread_create(&tRxid, 0, pRx, this) == 0)
	{
	  pthread_detach(tRxid);
	}
#else

	m_pMainThread = new Thread((IThread::FXN)thisMainProcessThread);
	m_pMainThread->Start(nullptr);

	m_pRxThread = new Thread((IThread::FXN)&clsRS485::RxProcessThread);
	m_pRxThread->Start(nullptr);

#endif
}


clsRS485::~clsRS485() {
	delete m_pRS485Mutex ;
	delete m_pRS485RxBufferMutex;
	delete m_pRS485TxBufferMutex;

	delete m_sRxRingBuffer;

	delete m_pRS485TxQueue;
	delete m_pRS485UartHandler;

	delete m_pRS485DEPin;
}

void 	clsRS485::RxRingBuffLock()
{
	if(m_pRS485RxBufferMutex!=nullptr)
		m_pRS485RxBufferMutex->lock();
}

void 	clsRS485::RxRingBufferUnlock()
{
	if(m_pRS485RxBufferMutex!=nullptr)
		m_pRS485RxBufferMutex->unlock();
}


void 	clsRS485::SetBaudrate(uint32_t u32Baud)
{
	if (m_pRS485UartHandler == nullptr)
		return;

	m_pRS485UartHandler->setBaudRate(u32Baud);
}

uint8_t clsRS485::SetMode(uint8_t u8DataBit, mraa::UartParity parity, uint8_t u8StopBit)
{
	if(m_pRS485UartHandler == nullptr)
		return 0xFF;

	return m_pRS485UartHandler->setMode(u8DataBit, parity, u8StopBit );
}
BOOL 	clsRS485::SendData(ProtoFrame_t sFrame)
{
	m_pRS485TxBufferMutex->lock();
	if(m_pRS485TxQueue->size() <= COMM_RS485_TX_QUEUE_SIZE)
		m_pRS485TxQueue->push(sFrame);
	m_pRS485TxBufferMutex->unlock();
	return TRUE;
}


void 	clsRS485::SetSendingIntervalMs(uint32_t u32Miliseconds)
{
	m_u32SendingInterval = u32Miliseconds;
}

// ================================ Threads =============================================

void	clsRS485::MainProcessThread(void *pArgs, bool *bIsTerminate)
{
	LREP("RxThread #%d Started", m_u8BusNumber);

	uint8_t cReadByte;

	for(;;)
	{
//		LREP_RAW("#");
		// Rx Process
		m_pRS485DEPin->write(LOW);
		auto t0 = std::chrono::system_clock::now();
		while (m_pRS485UartHandler->dataAvailable(m_u32SendingInterval))
		{
			auto t1 = std::chrono::system_clock::now();

			auto u32delta = std::chrono::duration_cast<std::chrono::milliseconds>(t1 - t0);

			if(u32delta.count() > COMM_RS485_RESPONSE_TIMEOUT_MS)
			{
				LREP_WARNING("RS485 read timed out!");
				m_pLogger->LogWarning("RS485 read timed out!");
				break;
			}


			int len = m_pRS485UartHandler->read((char*)&cReadByte, 1);
			if (len == 1)
			{
				if(m_sRxRingBuffer->BufferPush((void*)&cReadByte) != TRUE)
					LREP("#%d Unable to push data rxRingBuff", m_u8BusNumber);
			}
		}

		m_pRS485UartHandler->flush();

		// Process Tx Ringbuff
		int16_t txBuffLen = m_pRS485TxQueue->size();
		if (txBuffLen > 0)
		{
			// Pop out the Frame to be sent
			LREP("Tx Queue #%d len: %d", m_u8BusNumber, txBuffLen);
			ProtoFrame_t frame = m_pRS485TxQueue->front();
			m_pRS485TxQueue->pop();

#if 1
			m_pRS485DEPin->write(HIGH);

#if (RS485_DEBUG_ENABLE == ON)
			LREP("begin sending...");
			for(int i = 0; i < frame.len; i++)
				LREP_RAW("%.2x ", frame.data[i]);
			LREP("");
#endif
			if(m_pRS485UartHandler->write((const char*)frame.data, frame.len) != frame.len)
				LREP("Eror while send data");
			m_pRS485UartHandler->flush();
			usleep(2000);
			m_pRS485DEPin->write(LOW);

			delete frame.data;
#endif
		}
	}
}



void 	clsRS485::ProcessReceivedData()
{
//	RS485State_t		state =	RS485_STATE_IDLE;
	uint8_t 			ucTmp;
//	static BOOL			bIsSearchingHeader	= TRUE;
//	static uint8_t		pucRecvFrame[258] = {0};
//	static uint8_t		u8RecvDataCount		= 0;
//	static ProtocType_t	u8ProtocType		= PROTO_TYPE_UNDEFINED;	// Protocol type: 0-Undefined, 1-SMBUS, 2-RSP
	while(m_sRxRingBuffer->BufferGetCount() > 0)
	{

//		LREP("RxRingBUff count; %d",m_sRxRingBuffer->BufferGetCount() );
		// Layer 2 Starts processing received data from Layer 1 by searching Header
		if(bIsSearchingHeader)
		{
			// Start receiving only if received at least a header
			if(m_sRxRingBuffer->BufferGetCount() < MIN(SMBUS_FRM_HDR_SIZE, RSP_FRM_HDR_SIZE))
			{
				break;
			}

			// search for RSP_SOF
			m_sRxRingBuffer->BufferPop(&ucTmp);
			// Seek for a valid preamble

			// first byte seem to a SMBUS_SOF_PREAMBLE
			if(ucTmp == SMBUS_SOF_PREAMBLE)
			{
				m_sRxRingBuffer->BufferPop(&ucTmp);
				if(ucTmp == SMBUS_SOF_PREAMBLE)
				{
					u8ProtocType = PROTO_TYPE_SMBUS;

				}
				else
				{
					u8ProtocType = PROTO_TYPE_UNDEFINED;
					continue;
				}

			}
			else if (ucTmp == RSP_SOF_PREAMBLE)
			{
				m_sRxRingBuffer->BufferPop(&ucTmp);
				if(ucTmp == RSP_SOF_PREAMBLE)
				{
					u8ProtocType = PROTO_TYPE_RSP;
					// Continue receive full RSP header, then set isSearchingHeader to true

				}
				else
				{
					u8ProtocType = PROTO_TYPE_UNDEFINED;
					continue;
				}

			}

			// Found 2 continous byte seems to be a RSP_SOF
			// Try to get a full header for checking a valid one

			if(u8ProtocType == PROTO_TYPE_SMBUS)
			{
				m_sRxRingBuffer->BufferPopStream( &pucRecvFrame[SMBUS_FRM_IDX_DLEN], SMBUS_FRM_HDR_SIZE-SMBUS_FRM_IDX_DLEN);

				if (IsValidSMBUSDLen(pucRecvFrame[SMBUS_FRM_IDX_DLEN]))
				{
					bIsSearchingHeader = FALSE;
					continue;
				}
			}

			/**
			 * RSP Frame Structure
			 *
			 */
			//+-----+-----+------+------+-------+----------+----------+----------+----------+-------+------+-----+------+-------+
			//| SOF | SOF | DLEN | DLEN | FLAGS | DST_ADDR | DST_ADDR | SRC_ADDR | SRC_ADDR | CRC_H | DAT0 | ... | DATn | CRC_D |
			//+-----+-----+------+------+-------+----------+----------+----------+----------+-------+------+-----+------+-------+

			else if (u8ProtocType == PROTO_TYPE_RSP)
			{
				m_sRxRingBuffer->BufferPopStream( &pucRecvFrame[RSP_FRM_IDX_DLEN], RSP_FRM_HDR_SIZE - RSP_FRM_SOF_SIZE);
#if (RS485_DEBUG_ENABLE == ON)
				LREP_RAW("RSP header: ");
				for(int i = RSP_FRM_IDX_DLEN; i < RSP_FRM_IDX_DLEN + RSP_FRM_HDR_SIZE - RSP_FRM_SOF_SIZE; i ++)
					LREP_RAW("%.2x ", pucRecvFrame[i]);
#endif
				uint16_t u16Dlen = htons(*(uint16_t*)&pucRecvFrame[RSP_FRM_IDX_DLEN]);
#if (RS485_DEBUG_ENABLE == ON)
				LREP("\r\n[Firmware][RSP] Data len %d", u16Dlen);
#endif
				if (IS_DLEN_VALID(u16Dlen))
				{
					bIsSearchingHeader = FALSE;
					continue;
				}
			}
		}		// End of searching header

		else	// Start getting data field
		{
			if (u8ProtocType == PROTO_TYPE_SMBUS)
			{
				uint16_t i16PopLength = m_sRxRingBuffer->BufferGetCount();

				// Limit, if the receive buffer count is greater than data length of this frame then we just
				// get enough data byte for it
				if (i16PopLength > (int8_t)pucRecvFrame[SMBUS_FRM_IDX_DLEN] - SMBUS_FRM_HDR_SIZE + 2 - u8RecvDataCount)
				{
					i16PopLength = (int8_t)pucRecvFrame[SMBUS_FRM_IDX_DLEN] - SMBUS_FRM_HDR_SIZE + 2 - u8RecvDataCount;
				}
	//			LREP("Pop out %d data bytes, u8RecvDataCount: %d, len_required: %d", u8PopLength, u8RecvDataCount, pucRecvFrame[SMBUS_FRM_IDX_DLEN] - SMBUS_FRM_HDR_SIZE + 2);

				if(i16PopLength <= 0)
					continue;

				if(m_sRxRingBuffer->BufferPopStream(&pucRecvFrame[SMBUS_FRM_IDX_DST_DATA0+u8RecvDataCount], i16PopLength) != i16PopLength)
					LREP("Unable to Pop stream");

	//			// Count up the number of received data for the current frame
				u8RecvDataCount += i16PopLength;

	//			// If we didn't get enough data bytes, continue to check, do not switch to "Search header" state & return TRUE
				if (u8RecvDataCount < (uint8_t)pucRecvFrame[SMBUS_FRM_IDX_DLEN] - SMBUS_FRM_HDR_SIZE + 2)
				{
					continue;
				}
	#if (RS485_DEBUG_ENABLE == ON)
				LREP_RAW("Get Full Data: ");
				for (int i = 0; i < u8RecvDataCount; i ++)
					LREP_RAW("%.2x ", pucRecvFrame[SMBUS_FRM_IDX_DST_DATA0 + i]);
	#endif
				// Got a complete frame then switch the machine to "Search Header" state
				bIsSearchingHeader	= TRUE;
				u8RecvDataCount		= 0;
				u8ProtocType		= PROTO_TYPE_UNDEFINED;
#if 0
				// Decode SMBUS Frame
				TransSmartBus::SMBusFrame_t frame = TransSmartBus::clsTransSmartBus::DecodeFrame(&pucRecvFrame[2]);

//				if(frame.dlen == 0)
//				{
//					LREP("Invalid CRC, request all relay boxes status");
//					uint8_t data[] = {0xAA, 0xAA, 0x0B, 0xFF, 0xFF, 0x00, 0x17, 0x00, 0x33, 0x01, 0x01, 0xE9, 0xEE};
//
//					for(uint8_t idx = 1; idx < 5; idx ++)
//					{
//						data[10] = idx;
//						Pack_crc(&data[2], sizeof(data)-4);
//
//						ProtoFrame_t sFrame;
//						sFrame.len = sizeof(data);
//						sFrame.data = new uint8_t[sFrame.len];
//						memcpy(sFrame.data, data, sFrame.len);
//						SendData(sFrame);
//					}
//					memset(pucRecvFrame, 0, sizeof(pucRecvFrame));
//					break;
//				}
				clsSMBusProcessor::Instance()->Process((void*)&frame);
#else
				uint16_t u16FrameLen = pucRecvFrame[SMBUS_FRM_IDX_DLEN] + 2; // dlen + 2 bytes crc
				uint8_t* pvFrame = new uint8_t[u16FrameLen];
				memcpy(pvFrame, &pucRecvFrame[SMBUS_FRM_IDX_DLEN], u16FrameLen);

//				LREP("[%s:%d] Raw Frame", __FILE__, __LINE__);
//				for(int i = 0; i < u16FrameLen; i ++)
//				{
//					LREP_RAW("%.2x ", pvFrame[i]);
//				}

				clsSMBusProcessor::Instance()->Process((void*)pvFrame);
				delete pvFrame;
#endif
				memset(pucRecvFrame, 0, sizeof(pucRecvFrame));
				break;
			}

			else if (u8ProtocType == PROTO_TYPE_RSP)
			{
				uint16_t i16PopLength = m_sRxRingBuffer->BufferGetCount();

				uint16_t u16Dlen = htons(*(uint16_t*)&pucRecvFrame[RSP_FRM_IDX_DLEN]);
				// Limit, if the receive buffer count is greater than data length of this frame then we just
				// get enough data byte for it

				if (i16PopLength > u16Dlen + RSP_FRM_CRCD_SIZE - u8RecvDataCount)
				{
					i16PopLength = u16Dlen + RSP_FRM_CRCD_SIZE - u8RecvDataCount;
				}


				// Pop out the rest of frame (including CRC16)

	//			LREP("Pop out %d data bytes, u8RecvDataCount: %d, len_required: %d", u8PopLength, u8RecvDataCount, pucRecvFrame[SMBUS_FRM_IDX_DLEN] - SMBUS_FRM_HDR_SIZE + 2);
				if(i16PopLength <= 0)
					continue;
				if(m_sRxRingBuffer->BufferPopStream(&pucRecvFrame[RSP_FRM_IDX_DATA0+u8RecvDataCount], i16PopLength) != i16PopLength)
					LREP("Unable to Pop stream");


	//			// Count up the number of received data for the current frame
				u8RecvDataCount += i16PopLength;

	//			// If we didn't get enough data bytes, continue to check, do not switch to "Search header" state & return TRUE
				if (u8RecvDataCount < u16Dlen + RSP_FRM_CRCD_SIZE)
				{
					continue;
				}
#if (RS485_DEBUG_ENABLE == ON)
				LREP("Get Full Data: ");
				for (int i = 0; i < u8RecvDataCount; i ++)
					LREP_RAW("%.2x ", pucRecvFrame[RSP_FRM_IDX_DATA0 + i]);
#endif
				// Got a complete frame then switch the machine to "Search Header" state
				bIsSearchingHeader	= TRUE;
				u8RecvDataCount		= 0;
				u8ProtocType		= PROTO_TYPE_UNDEFINED;

				// Decode RSP Frame
//				TransRSP::RSPFrame_t frame = TransRSP::clsTransRSP::DecodeFrame(&pucRecvFrame[RSP_FRM_IDX_DLEN]);
				uint16_t u16FrameLen = RSP_FRM_HDR_SIZE + u16Dlen + RSP_FRM_CRCD_SIZE + RSP_FRM_SOF_SIZE;
				uint8_t* pvFrame = new uint8_t[u16FrameLen];
				memcpy(pvFrame, &pucRecvFrame[RSP_FRM_IDX_DLEN], u16FrameLen);

//				LREP("Raw Frame");
//				for(int i = 0; i < u16FrameLen; i ++)
//				{
//					LREP_RAW("%.2x ", pvFrame[i]);
//				}

//				clsRSPProcessor::Instance()->Process((void*)&pucRecvFrame[RSP_FRM_IDX_DLEN]);
				clsRSPProcessor::Instance()->Process((void*)pvFrame);
				delete pvFrame;
				memset(pucRecvFrame, 0, sizeof(pucRecvFrame));
				break;
			}

		}	// End of getting data
//
	}	// End of while loop
//	return FALSE;
}

void 	clsRS485::RxProcessThread(void *pArgs, bool *bIsTerminate)
{
	LREP("RxProcessThread#%d is Started", m_u8BusNumber);

	for(;;)
	{
		ProcessReceivedData();
		std::this_thread::sleep_for(std::chrono::milliseconds(2));
	}
}
#if 0
void clsRS485::TxProcessThread(void* pvArgs, bool *bIsTerminate)
{
	uint16_t txBuffLen = 0;
	while(1)
	{
		txBuffLen = m_sTxRingBuffer->BufferGetCount();
		if (txBuffLen > 0)
		{
			LREP_RAW(".");
			uint8_t *pu8TxBuffer = new uint8_t[txBuffLen];
			m_sTxRingBuffer->BufferPopStream((void*)pu8TxBuffer, txBuffLen);

			for(int i = 0; i < txBuffLen; i++)
			{
				LREP_RAW("%.2x ", pu8TxBuffer[i]);
			}
			// Send to UART
			m_pRS485Mutex->lock();
//
			m_pRS485DEPin->write(HIGH);
			m_pRS485UartHandler->setMode(8, mraa::UART_PARITY_EVEN, 1);
			m_pRS485UartHandler->write((const char*)pu8TxBuffer, txBuffLen);
			m_pRS485UartHandler->flush();
			m_pRS485DEPin->write(LOW);
//
			m_pRS485Mutex->unlock();

			delete pu8TxBuffer;
		}
//		std::this_thread::sleep_for(std::chrono::milliseconds(200));
	}

}
#endif




} /* namespace AHGSystems */
