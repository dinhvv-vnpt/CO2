/*
 * IComm.cpp
 *
 *  Created on: May 10, 2017
 *      Author: MANHBT
 */

#include "IComm.h"

namespace AHGSystems {

IComm::IComm() {

}

IComm::~IComm() {
}

} /* namespace Agriculture */
