/*
 * clsLogger.cpp
 *
 *  Created on: Aug 9, 2017
 *      Author: MANHBT
 */

#include "clsLogger.h"


namespace AHGSystems {

clsLogger::clsLogger() {

	m_t = time(0);
	m_thistime = nullptr;
}

clsLogger::clsLogger(std::string szFileName)
{
	m_t = time(0);
	m_thistime = nullptr;
	m_szLogFileName = szFileName;
}

clsLogger::~clsLogger() {
}

void clsLogger::SetFileName(std::string szFileName)
{
	m_szLogFileName = szFileName;
}

void clsLogger::LogError(const char* string, ...)
{
	char 	szBuffer[2048];
	char	szCmd[2048];
	va_list arglist;
	va_start(arglist, string);
	memset(szBuffer, 0, 2048);
	#ifdef _MSC_VER
	vsprintf_s(szBuffer, 2047, string, arglist);
	#elif defined(__GNUC__)
	vsprintf(szBuffer, string, arglist);
	#endif
	m_t = time(0);
	m_thistime = localtime(&m_t);
	snprintf(
		szCmd, sizeof(szCmd),
		"echo \"[%.2d-%.2d-%.2d %.2d:%.2d:%.2d] [ERR] %s\" >> %s",
		m_thistime->tm_year+1900,
		m_thistime->tm_mon + 1,
		m_thistime->tm_mday,
		m_thistime->tm_hour,
		m_thistime->tm_min,
		m_thistime->tm_sec,
		szBuffer,
		(char*)m_szLogFileName.c_str()
		);
	system(szCmd);
}


void clsLogger::LogWarning(const char* string, ...)
{
	char 	szBuffer[2048];
	char	szCmd[2048];
	va_list arglist;
	va_start(arglist, string);
	memset(szBuffer, 0, 2048);
	#ifdef _MSC_VER
	vsprintf_s(szBuffer, 2047, string, arglist);
	#elif defined(__GNUC__)
	vsprintf(szBuffer, string, arglist);
	#endif
	m_t = time(0);
	m_thistime = localtime(&m_t);
	snprintf(
		szCmd, sizeof(szCmd),
		"echo \"[%.2d-%.2d-%.2d %.2d:%.2d:%.2d] [WARN] %s\" >> %s",
		m_thistime->tm_year+1900,
		m_thistime->tm_mon + 1,
		m_thistime->tm_mday,
		m_thistime->tm_hour,
		m_thistime->tm_min,
		m_thistime->tm_sec,
		szBuffer,
		(char*)m_szLogFileName.c_str()
		);
	system(szCmd);
}

void clsLogger::LogInfo(const char* string, ...)
{
    char 	szBuffer[2048];
    char	szCmd[2048];
    va_list arglist;
    va_start(arglist, string);
    memset(szBuffer, 0, 2048);
#ifdef _MSC_VER
    vsprintf_s(szBuffer, 2047, string, arglist);
#elif defined(__GNUC__)
    vsprintf(szBuffer, string, arglist);
#endif
    m_t = time(0);
    m_thistime = localtime(&m_t);
    snprintf(
    	szCmd, sizeof(szCmd),
    	"echo \"[%.2d-%.2d-%.2d %.2d:%.2d:%.2d] [INFO] %s\" >> %s",
    	m_thistime->tm_year+1900,
    	m_thistime->tm_mon + 1,
    	m_thistime->tm_mday,
    	m_thistime->tm_hour,
    	m_thistime->tm_min,
    	m_thistime->tm_sec,
		szBuffer,
    	(char*)m_szLogFileName.c_str()
    	);
    system(szCmd);

}

} /* namespace AHGSystems */
