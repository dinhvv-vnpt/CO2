/*
 * clsDeviceManager.cpp
 *
 *  Created on: May 10, 2017
 *      Author: MANHBT
 */

#include "clsDeviceManager.h"
#include "config.h"
#include "Debug.h"
#include <iostream>
#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"

#include "clsCO2Sensor.h"


namespace AHGSystems {


clsDeviceManager* 		pDevManager = nullptr;
std::unordered_map<std::string, std::shared_ptr<IDevice>> m_lstRegisteredDevices;
//std::unordered_map<std::string, int> m_lstSupportedCommand; // <szCommand, u8Command> mapping
std::unordered_map<std::string, std::shared_ptr<IDevice>> m_lstSupportedCommand; // <szCommand, u8Command> mapping

std::string 			m_szGatewayID;
Thread* 				m_pBackgroundThread = nullptr;
Thread*					m_pIOCheckerThread = nullptr;
DevManMode_t			m_mode = OP_MODE_AUTO;
std::mutex*				g_pMutex;

clsRS485* g_pDevManRSPBus 		= nullptr;
clsRS485* g_pDevManSBBus		= nullptr;

clsRS485* g_pDevManMBUS			= nullptr;

CallbackFunction		m_onStatusChangedCbFunction = nullptr;



clsDeviceManager::clsDeviceManager()
{
	m_lstRegisteredDevices.clear();
	m_lstSupportedCommand.clear();
	m_szGatewayID = "";
	m_pBackgroundThread = nullptr;
	m_pIOCheckerThread = nullptr;
	m_mode = OP_MODE_MANUAL;

	g_pMutex = new std::mutex();

	LREP("Initialize Device List... \r\n");
	DeviceInitialize();
	LREP("Device List Initialized! \r\n");

//	m_pBackgroundThread = new Thread(&SensorUpdateProc);
//	m_pBackgroundThread->Start(nullptr);
//
//
////	m_pIOCheckerThread = new Thread(&InputDeviceReadProc);
////	m_pIOCheckerThread->Start(nullptr);
//
//	LREP("Device Manager is started, turn off all actuator!");
//	for (auto itr = m_lstRegisteredDevices.begin(); itr != m_lstRegisteredDevices.end(); itr++) {
//		if (IsDigitalOutDevice(itr->second->GetDevType()))
//		{
//			LREP("Turn OFF device %s", itr->second->GetDeviceDescription().c_str());
//			itr->second->ExecuteCommand(CMD_ACTUATOR_OFF, itr->second->GetDevType());
//		}
//	}
//



	std::this_thread::sleep_for(std::chrono::seconds(1));
//	OnModeChanged((void*)g_pGpioModeSelect);

}

clsDeviceManager::~clsDeviceManager()
{
}

//-------------------------------------------Public Functions------------------------------------------------

DevType_t clsDeviceManager::GetDeviceType(std::string devID)
{

	DevType_t result = DEV_TYPE_END;
	for (auto itr = m_lstRegisteredDevices.begin(); itr != m_lstRegisteredDevices.end(); itr++)
	{
		if (itr->first == devID)
		{
			result = itr->second->GetDevType();
		}
	}
	return result;
}

clsDeviceManager* clsDeviceManager::Instance()
{
	if(pDevManager == nullptr)
	{
		pDevManager = new clsDeviceManager();
	}

	return pDevManager;
}

std::list<std::string> clsDeviceManager::GetRegisteredDeviceList()
{
	std::list<std::string> result;
	for (auto itr = m_lstRegisteredDevices.begin(); itr != m_lstRegisteredDevices.end(); itr++)
	{
		if(itr->second->IsVisible() == true)
		{
			result.push_front(itr->first);
		}
	}
	return result;
}

std::list<std::string> 	clsDeviceManager::GetListCommand()
{
	std::list<std::string> result;
	for (auto itr = m_lstSupportedCommand.begin(); itr != m_lstSupportedCommand.end(); itr++)
	{
		result.push_front(itr->first);
	}
	return result;
}

uint16_t clsDeviceManager::GetNumberOfRegisteredDevice()
{
	return m_lstRegisteredDevices.size();
//	uint16_t u16TotalVisibledDevices = 0;
//	for (auto itr = m_lstRegisteredDevices.begin(); itr != m_lstRegisteredDevices.end(); itr++)
//	{
//		if(itr->second->IsVisible() == true)
//			u16TotalVisibledDevices++;
//	}
//	return u16TotalVisibledDevices;
}

/**
 * @brief ExecuteSimpleCommand
 * @param devID string of device ID
 * @param u16Cmd command in command list
 * @param u16SubCmd sensor type:
 * @return for sensor node: return 0xEFFF if error,
 *                          return sensor value in case of succes
 *         for valve and pump: return EFFF if error occur
 *                      for command: get/set status return current status
 *                      ACTUATOR_STATUS_ON/OFF of valve and pump
 */
// TODO: [manhbt] Implement for corresponding application (APP_TYPE)
int16_t 	clsDeviceManager::ExecuteSimpleCommand(std::string devID, uint16_t u16Cmd, uint16_t u16DevType)
{

	int16_t	i16RetValue = 0xEFFF;

	std::shared_ptr<IDevice> pDev = nullptr;

	for (auto itr = m_lstRegisteredDevices.begin(); itr != m_lstRegisteredDevices.end(); itr++)
	{
		if (itr->first == devID)
		{
			if (itr->second->GetDevType() == u16DevType)
			{
				pDev = itr->second;
			}
		}
	}
	if(pDev == nullptr)
	{
//		std::cout << "[ERR] unable to find device type "<< u16DevType << " with ID " << devID << std::endl;
		LREP("Unable to find device type %d with ID %s", u16DevType, devID.c_str());
		return i16RetValue;
	}

	return pDev->ExecuteCommand(u16Cmd, u16DevType);
}

// TODO: [manhbt] Implement for corresponding application (APP_TYPE)
char* 	clsDeviceManager::GetCurrentStatusDevice(std::string devID)
{

	int16_t *pu16Response = new int16_t;
	*pu16Response = -1;

#if 0
	if(devID == "GATEWAY")
	{

		g_pMutex->lock();
		m_jsonBuilder.Clear();

	//	{
	//	  "device_type": 0,
	//	  "device_id": "985dad3a89e0",
	//	  "gateway_id":"985dad3a89e0",
	//	  "device_description": "GATEWAY",
	//	  "hardware_address": "0",
	//	  "device_values": [
	//	  "param": "status",
	//	  "value": 0-1 //manual-auto
	//	  }
	//	  ]
	//	 }
		rapidjson::Writer<rapidjson::StringBuffer> writer(m_jsonBuilder);

		writer.SetMaxDecimalPlaces(2);
		writer.StartObject();               // Between StartObject()/EndObject(),

		writer.Key("device_type");
		writer.Int(0);

		writer.Key("device_id");
		writer.String(m_szGatewayID.c_str());

		writer.Key("gateway_id");
		writer.String(m_szGatewayID.c_str());


		writer.Key("device_description");
		writer.String("GATEWAY");

	//	char tmp[10];

		writer.Key("hardware_address");
	//	sprintf(tmp, "%.4x:%.2x", m_u16SMBusID, m_i8PortNumber);
		writer.String("0");

		writer.Key("device_values");
		writer.StartArray();

		// Water temperature
		writer.StartObject();
		writer.Key("param");
		writer.String("status");

		writer.Key("value");
		writer.Int(g_pGpioModeSelect->read());
		writer.EndObject();

		writer.EndArray();
		writer.EndObject();

		g_pMutex->unlock();

		LREP("Get GATEWAY Status: %s", m_jsonBuilder.GetString());
		return (char*)m_jsonBuilder.GetString();

	}
#endif

	std::shared_ptr<IDevice> pDev = nullptr;

	for (auto itr = m_lstRegisteredDevices.begin(); itr != m_lstRegisteredDevices.end(); itr++)
	{
		if ((itr->first == devID))
		{
			pDev = itr->second;
		}
	}
	if(pDev == nullptr)
	{
		std::cout << "[ERR] unable to find device with ID " << devID <<std::endl;
		return nullptr;
	}

	return  pDev->GetCurrentStatus();

}

//-------------------------------------------Private Functions------------------------------------------------
void 	clsDeviceManager::RegisterDevice(std::string szDeviceID, std::shared_ptr<IDevice> pDevice)
{
	m_lstRegisteredDevices.insert(std::make_pair(szDeviceID, pDevice));

	//TODO: [manhbt] Register commands
//	if(pDevice->GetDevType() == DEV_TYPE_TANK)
//	{
//		std::unordered_map<std::string, int> lstCmd = std::dynamic_pointer_cast<clsHydroponicTank>(pDevice)->GetListSupportedCommand();
//		for(auto itr = lstCmd.begin(); itr !=lstCmd.end(); itr++)
//		{
//			m_lstSupportedCommand.insert(std::make_pair(itr->first, pDevice));
//		}
//	}
}

void 	clsDeviceManager::RemoveDevice(std::string szDeviceID)
{
	for (auto itr = m_lstRegisteredDevices.begin(); itr != m_lstRegisteredDevices.end(); itr++)
	{
		if (itr->first == szDeviceID)
		{
			m_lstRegisteredDevices.erase(itr);
		}
	}
}

void 	clsDeviceManager::UpdateDevices()
{
	for (auto itr = m_lstRegisteredDevices.begin(); itr != m_lstRegisteredDevices.end(); itr++)
	{
		itr->second->UpdateValues(nullptr);
	}
}

// TODO: [manhbt] Implement for corresponding application (APP_TYPE)
void 	clsDeviceManager::DeviceInitialize()
{

	std::shared_ptr<clsCO2Sensor> sensor1 = std::make_shared<clsCO2Sensor>();

	sensor1->SetDevType(DEV_TYPE_SENSOR_NODE);
	sensor1->SetDeviceDescription("VINECO CO2 Sensor");
	sensor1->SetVisible(true);


	RegisterDevice(DEVMAN_DEV_CO2_SENSOR_ID, sensor1);


}

/**
 * Enable/disable buttons on Relay boxes
 * @param bDisable: 1 - disable all relay-box buttons
 * 					0 - enable all relay-box buttons
 */
void	clsDeviceManager::DisableRelayBoxButtons(bool bDisable)
{

	if(g_pDevManSBBus == nullptr)
	{
		LREP_ERROR("SBUS Controller is not set!");
		return;
	}

	//	+------+------+------------+------------+----------+---------+------------+------------+---------+-----+---------+-------+
	//	| SOF  | DLEN | SRC_SUB_ID | SRC_DEV_ID | DEV_TYPE | OP_CODE | DST_SUB_ID | SDT_DEV_ID | DATA[0] | ... | DATA[n] | CRC_D |
	//	| (2B) | (1B) | (1B)       | (1B)       | (2B)     | (2B)    | (1B)       | (1B)       |         |     |         | (2B)  |
	//	+------+------+------------+------------+----------+---------+------------+------------+---------+-----+---------+-------+
	//	  AAAA    0F       0C            FE        FF FE      00 31     01          0C             01   64 00 01            B22F
	uint8_t data[] = {0xAA, 0xAA,
		0x0C,
		0x0C, 0xFE,
		0xFF, 0xFE,
		0x02, 0x82,		// modidy lock command
		0xFF, 0xFF,// Dst addr - broadcast
		bDisable,// 1 = disable, 0 = enable
		0xB2, 0x2F// CRC
	};

	ProtoFrame_t sFrame;
	sFrame.len = sizeof(data);

	Pack_crc(&data[2], sizeof(data) - 4);
	sFrame.data = new uint8_t[sFrame.len];
	memcpy(sFrame.data, data, sizeof(data));

//	LREP ("Locking Relay button....");
//
//	for (int i = 0; i < sFrame.len; i ++)
//	{
//		LREP_RAW("%.2x ", sFrame.data[i]);
//	}
//
//	LREP("");

	g_pDevManSBBus->SendData(sFrame);


}


#if 0
/**
 * Main loop for Reading GPIO Input thread
 * @param pArgs
 * @param bIsTerminate
 */
void clsDeviceManager::InputDeviceReadProc(void *pArgs, bool *bIsTerminate)
{
	LREP("InputReader Thread is started, turn off all actuator!");
	for (auto itr = m_lstRegisteredDevices.begin(); itr != m_lstRegisteredDevices.end(); itr++) {
		if (IsDigitalOutDevice(itr->second->GetDevType()))
		{
			LREP("Turn OFF device %s", itr->second->GetDeviceDescription().c_str());
			itr->second->ExecuteCommand(CMD_ACTUATOR_OFF, itr->second->GetDevType());
		}
	}

	while(1)
	{
		for (auto itr = m_lstRegisteredDevices.begin(); itr != m_lstRegisteredDevices.end(); itr++) {
			if ((itr->second->GetDevType() == DEV_TYPE_INPUT_DIGITAL))
			{
				if (itr->second->ReadValue() == 0)
				{
					auto start = std::chrono::system_clock::now();
					while(itr->second->ReadValue() == 0);
					auto now = std::chrono::system_clock::now();
					auto msec = std::chrono::duration_cast<std::chrono::milliseconds>(now - start);
//					LREP("%s is pressed in %llums", itr->second->GetDeviceID().c_str(), msec.count());
					if(msec.count() > BUTTON_PRESSED_DETECT_TIME_MS)
					{
//						std::dynamic_pointer_cast<clsPushButton>(itr->second)->InvokeCommand(nullptr, nullptr);

						m_onStatusChangedCbFunction(itr->second->GetDeviceID(), itr->second->GetCurrentStatus());

					}
				}
			}
		}
		std::this_thread::sleep_for(std::chrono::milliseconds(10));

	}
}
#endif

/**
 * Register callback function for every event trigged
 * @param eventType Event type
 * @param fcn : fucntion pointer
 */
void clsDeviceManager::RegisterCallback(Event_t eventType, CallbackFunction fcn, std::string szGatewayID)
{
	switch (eventType)
	{
		case DEV_EVENT_TYPE_ON_STATUS_CHANGED:
			m_szGatewayID = szGatewayID;
			m_onStatusChangedCbFunction = fcn;
			for (auto itr = m_lstRegisteredDevices.begin(); itr != m_lstRegisteredDevices.end(); itr++)
			{
				itr->second->RegisterCallback(fcn, szGatewayID, nullptr);
			}

			break;
		// TODO: [manhbt] Add support for more event of device, such as on-connect, on-disconnect, etc...
		default:
			break;
	}

}


/**
 * Execute command
 * @param szCommand command will be executed, must be formated as below:
 *  <DeviceID>:<Action>, where:
 *  <DeviceID>: the device ID was declared in m_lstRegiteredDevices
 *  <Action>: the command for execute
 * @return
 */
int16_t clsDeviceManager::ExecuteCommand(std::string szCommand)
{
#if 0
	// TODO: find the command in supported command list

	char* pcFoundCommand = nullptr;
	uint16_t	u16Cmd;

	for (auto itr = m_lstSupportedCommand.begin(); itr != m_lstSupportedCommand.end(); itr++) {
		if(strstr(szCommand.c_str(), itr->first.c_str()) != nullptr)
//		if(itr->first == szCommand)
		{
			pcFoundCommand = (char*)szCommand.c_str();
			u16Cmd = itr->second;
			break;
		}
	}

	if(pcFoundCommand == nullptr)
	{
		LREP("Command Not Found!");
				return FALSE;
	}


	 std::shared_ptr<IDevice> pDevice = nullptr;
	 std::string szDeviceID, szSubCommand;
	 char* pTmp = nullptr;

	for (auto itr = m_lstRegisteredDevices.begin(); itr != m_lstRegisteredDevices.end(); itr++) {
		pTmp = strstr(pcFoundCommand, itr->second->GetDeviceID().c_str());

		if(pTmp != nullptr)
		{
			pDevice = itr->second;
			szDeviceID = itr->second->GetDeviceID();
			strncpy((char*)szSubCommand.c_str(), pTmp + strlen(szDeviceID.c_str()) , strlen(pTmp) - strlen(szDeviceID.c_str()));
		}
	}

	if(pDevice == nullptr)
	{
		LREP("Device Not Found!");
		return FALSE;
	}

	// TODO: Decode the Sub-command
//	LREP("Device ID: %s", szDeviceID.c_str());
//	LREP("Sub-command: %s", szSubCommand.c_str());
//	LREP("Execute command: %d, %d", u16Cmd, pDevice->GetDevType());


	return pDevice->ExecuteCommand(u16Cmd, pDevice->GetDevType());
#endif

	char fullcmd[128] = {0};
	strncpy(fullcmd, szCommand.c_str(), szCommand.length());

	char * pch;
	char cmd[128] = {0};

	pch = strtok (fullcmd,": ;");
	if(pch!= NULL)
	{
		strncpy(cmd, pch, strlen(pch));
	}

	std::unordered_map<std::string, std::shared_ptr<IDevice>>::const_iterator got = m_lstSupportedCommand.find(cmd);

	if ( got == m_lstSupportedCommand.end() )
	{
		LREP("Command Not Found!");
		return -1;
	}

	return got->second->ExecuteCommand(szCommand.c_str());

	delete pch;
}

#if 0
void clsDeviceManager::OnModeChanged(void* pvParent)
{

	mraa::Gpio* pModeSelect = (mraa::Gpio*)pvParent;
	if(pModeSelect == nullptr)
	{
		return;
	}

	std::this_thread::sleep_for(std::chrono::milliseconds(BUTTON_PRESSED_DETECT_TIME_MS));

	int mode = pModeSelect->read();

	// Manual mode
	if(mode == 0)
	{
		LREP("Manual mode selected!");
		LREP ("Unlocking Relay buttons....");
		DisableRelayBoxButtons(false);
		DisableRelayBoxButtons(false);
		DisableRelayBoxButtons(false);

		LREP("Stop all tanks and cooling systems!");
		for (auto itr = m_lstRegisteredDevices.begin(); itr != m_lstRegisteredDevices.end(); itr++)
		{
			if(itr->second->GetDevType() == DEV_TYPE_TANK)
			{
				LREP("Exec %s CMD_TANK_STOP: %d", itr->second->GetDeviceID().c_str(), itr->second->ExecuteCommand(CMD_TANK_STOP, itr->second->GetDevType()));
			}
			else if (itr->second->GetDevType() == DEV_TYPE_COOLING_SYSTEM)
			{
				LREP("Exec %s CMD_COOL_STOP: %d", itr->second->GetDeviceID().c_str(), itr->second->ExecuteCommand(CMD_COOL_STOP, itr->second->GetDevType()));
			}
		}
	}

	else
	{
		LREP("Automatic mode selected!");
		LREP ("Locking Relay buttons....");
		DisableRelayBoxButtons(true);
		DisableRelayBoxButtons(true);
		DisableRelayBoxButtons(true);
	}

	if(m_onStatusChangedCbFunction != nullptr)
	{
		g_pMutex->lock();
		m_jsonBuilder.Clear();

		rapidjson::Writer<rapidjson::StringBuffer> writer(m_jsonBuilder);

		writer.SetMaxDecimalPlaces(2);
		writer.StartObject();               // Between StartObject()/EndObject(),

		writer.Key("device_type");
		writer.Int(0);

		writer.Key("device_id");
		writer.String(m_szGatewayID.c_str());

		writer.Key("gateway_id");
		writer.String(m_szGatewayID.c_str());


		writer.Key("device_description");
		writer.String("GATEWAY");

	//	char tmp[10];

		writer.Key("hardware_address");
	//	sprintf(tmp, "%.4x:%.2x", m_u16SMBusID, m_i8PortNumber);
		writer.String("0");

		writer.Key("device_values");
		writer.StartArray();

		// Water temperature
		writer.StartObject();
		writer.Key("param");
		writer.String("status");

		writer.Key("value");
		writer.Int(mode);
		writer.EndObject();

		writer.EndArray();
		writer.EndObject();
		g_pMutex->unlock();

		m_onStatusChangedCbFunction(m_szGatewayID, (char*)m_jsonBuilder.GetString(), nullptr);
	}
}
#endif


} /* namespace Agriculture */

