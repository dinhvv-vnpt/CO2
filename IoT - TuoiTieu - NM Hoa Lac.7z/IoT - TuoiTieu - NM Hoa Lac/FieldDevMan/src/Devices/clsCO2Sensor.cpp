/*
 * clsCO2Sensor.cpp
 *
 *  Created on: May 10, 2017
 *      Author: MANHBT
 */

#include "clsCO2Sensor.h"
#include "TransRSP/clsTransRSP.h"
#include "config.h"
#include "Debug.h"
#include <string>
#include <ctime>
#include <iostream>
#include <CRC8.h>
#include <CRC16.h>


namespace AHGSystems {

clsCO2Sensor::clsCO2Sensor() {

	try {
		 m_pRS485UartHandler = new mraa::Uart(COMM_RS485_BUS2_UART_DEV_NAME);
	} catch (std::exception& e) {
		LREP("Error while setting up raw UART, do you have a uart?");
		std::terminate();
	}

	m_pRS485UartHandler->setBaudRate(COMM_RS485_BUS2_BAUD);

	mraa::Result res = m_pRS485UartHandler->setMode(COMM_RS485_BUS2_DATABIT, mraa::UART_PARITY_NONE, COMM_RS485_BUS2_STOPBIT);
	if(res != mraa::SUCCESS)
		LREP("failed to set up uart mode even");
	m_pRS485UartHandler->setFlowcontrol(false, false);

	m_pRS485DEPin = new mraa::Gpio(COMM_RS485_BUS2_DE_PIN_NUM);
	m_pRS485DEPin->dir(mraa::DIR_OUT);
	m_pRS485DEPin->mode(mraa::MODE_PULLUP);

	m_u8SensorType = DEV_TYPE_END;


	m_pSensorMutex = new std::mutex();

	m_szDescription = "";
	m_szDeviceID = "";

	m_lstCallbackFunctions.clear();

	m_pSensorUpdateTheadProc = 0;
	pthread_create(&m_pSensorUpdateTheadProc, NULL, (PthreadPtr)&clsCO2Sensor::SensorThreadProc, this );

}

clsCO2Sensor::~clsCO2Sensor() {
}


/**
 * @brief GetResponse
 * @param devID string of device ID
 * @param u16Cmd command in command list
 * @param u16SubCmd sensor type:
 * @return for sensor node: return 0xEFFF if error,
 *                          return sensor value in case of succes
 *         for valve and pump: return EFFF if error occur
 *                      for command: get/set status return current status
 *                      ACTUATOR_STATUS_ON/OFF of valve and pump
 */
/**
 * Request/Process Update data from Sensor nodes
 * @param pvArgs: RSP frame
 * 		is null: Sensor node update request
 * 		!= null: RSP frame received from RS485 Bus --> need to update sensor data
 * @return
 */

uint8_t clsCO2Sensor::UpdateValues(void *pvArgs)
{
	if (m_pRS485UartHandler == nullptr)
	{
		std::cout << "[SENS] Controller is not set!" << std::endl;
		return SENS_RESPONSE_HW_ERROR;
	}

	// Process Sensor node Update Request : Send request Frame to RS485 Tx queue
	int readLen;
	int total_rcv_bytes=0;
	char xC;
	uint8_t rcv_buffer[30];
//	float temp=0,value_co2=0;
	//B1: Send Cmd -> CO2
	uint8_t data[8];
	data[0]=0x01;
	data[1]=0x03;
	data[2]=0x01;
	data[3]=0x02;
	data[4]=0x00;
	data[5]=0x02;
	data[6]=0x64;
	data[7]=0x37;
//	ProtoFrame_t frame;
	m_pRS485DEPin->write(1);

	LREP("Send data:");
	for (int i = 0; i < 8; i++)
	{
		LREP_RAW("%.2x  ", data[i]);
	}
	m_pRS485UartHandler->write((const char*)data, 8);

	m_pRS485UartHandler->flush();

	m_pRS485DEPin->write(0);
	while (1)
	{

		if(m_pRS485UartHandler->dataAvailable(500))
		{

			readLen = m_pRS485UartHandler->read(&xC, 1);

			if (readLen == 1)
			{
				rcv_buffer[total_rcv_bytes] = xC;
				total_rcv_bytes++;
//				LREP_RAW(" %.2X ", (0xFF & xC));
				if(total_rcv_bytes>=30)
				break;
			}
		}
		else
		{
			break;
		}

	}
	LREP("Received data: %d bytes", total_rcv_bytes);
	for (int i = 0; i < total_rcv_bytes; i++)
	{
		LREP_RAW("%.2x  ", rcv_buffer[i]);
	}
// filter data
	if(total_rcv_bytes>=9)
	{
		int i=0;
		total_rcv_bytes=0;
		while(rcv_buffer[i]==0x00)
		{
		i++;
		}
		if((rcv_buffer[i]==0x01)&&(rcv_buffer[i+1]==0x03)&&(rcv_buffer[i+2]==0x04))
		{
			m_sSensorValues.dAirTemp = (float)(rcv_buffer[i+3]*256+	rcv_buffer[i+4])/100;
			m_sSensorValues.dCO2 = rcv_buffer[i+5]*256 + rcv_buffer[i+6];
		}
	//	switch (total_rcv_bytes)
	//	{
	//		case 9:
	//			if((rcv_buffer[0]==0x01)&&(rcv_buffer[1]==0x03)&&(rcv_buffer[2]==0x04))
	//			{
	//				m_sSensorValues.dAirTemp = (float)(rcv_buffer[3]*256+	rcv_buffer[4])/100;
	//				m_sSensorValues.dCO2 = rcv_buffer[5]*256 + rcv_buffer[6];
	//			}
	//			break;
	//		case 10:
	//			if((rcv_buffer[1]==0x01)&&(rcv_buffer[2]==0x03)&&(rcv_buffer[3]==0x04))
	//			{
	//				m_sSensorValues.dAirTemp = (float)(rcv_buffer[4]*256+	rcv_buffer[5])/100;
	//				m_sSensorValues.dCO2 = rcv_buffer[6]*256 + rcv_buffer[7];
	//			}
	//			break;
	//	}

		// callback to agent
	    for (auto itr = m_lstCallbackFunctions.begin(); itr != m_lstCallbackFunctions.end(); itr++)
	    {
	    	itr->first(m_szDeviceID, GenerateJson(), itr->second);
	    }

	}

	return 0;

}

/**
 *	Execute command
 * @param u16Cmd: Command <-> Command (read values command)
 * @param u16SubCmd: Sub-Command <-> Device type
 * @return: value of sensor
 */
int16_t clsCO2Sensor::ExecuteCommand(uint16_t u16Cmd, uint16_t u16SubCmd) {
	//	u16SubCmd = u16SubCmd;
	int16_t i16Result = 0xEFFF;
	if (u16SubCmd != m_u8SensorType) {
#if (SENS_DEBUG_ENABLE == ON)
		LREP("Device Type Invalid");
#endif
		return i16Result;
	}

	switch (u16Cmd) {
	default:
		std::cout << "Invalid Command!" << std::endl;
		break;
	}

	return i16Result;

}

/**
 * Register callback function
 * @param fcn invoked when status of sensor node changes (values changed)
 */
void	clsCO2Sensor::RegisterCallback(CallbackFunction fcn,std::string szGWID, void* pvParent)
{
	if(fcn != nullptr)
	{
		m_lstCallbackFunctions.insert(std::make_pair(fcn, pvParent));
		m_szGatewayID = szGWID;
	}
}


void 			clsCO2Sensor::RegisterInternalCallback(CallbackFunction fcn, void* pvParent)
{
	if(fcn != nullptr)
	{
	//		m_lstCallbackFunctions.push_back(fcn);
		m_lstInternalCallbackFunctions.insert(std::make_pair(fcn, pvParent));
	}
}
/**
 * Get the current status of Sensor node
 * @return: json formated string, contains the all status off sensor node
 */
char*	clsCO2Sensor::GetCurrentStatus()
{
	return GenerateJson();
}

char* 	clsCO2Sensor::GenerateJson(void)
{
	m_pSensorMutex->lock();
	m_jsonBuilder.Clear();
	rapidjson::Writer<rapidjson::StringBuffer> writer(m_jsonBuilder);
	writer.SetMaxDecimalPlaces(2);
	writer.StartObject();

		writer.Key("device_type");
		writer.Int(m_u8SensorType);

		writer.Key("device_id");
		writer.String(m_szDeviceID.c_str());

		writer.Key("gateway_id");
		writer.String(m_szGatewayID.c_str());

		writer.Key("device_values");
		writer.StartArray();

			// Air Temp
			writer.StartObject();
			writer.Key("param");
			writer.String("air_temperature");

			writer.Key("value");
			writer.Double(m_sSensorValues.dAirTemp);
			writer.EndObject();

			// CO2
			writer.StartObject();
			writer.Key("param");
			writer.String("CO2");

			writer.Key("value");
			writer.Double(m_sSensorValues.dCO2);
			writer.EndObject();

		writer.EndArray();
	writer.EndObject();
	m_pSensorMutex->unlock();
	return (char*)m_jsonBuilder.GetString();
}


void	clsCO2Sensor::SensorThreadProc(void *pArgs, bool *bIsTerminate)
{
	for(;;)
	{
		LREP("Updating Sensor values...");
		UpdateValues(nullptr);
		std::this_thread::sleep_for(std::chrono::seconds(30));
	}
}


} /* namespace Agriculture */


