/*
 * clsOnOffActuator.cpp
 *
 *  Created on: May 10, 2017
 *      Author: MANHBT
 */

#include "clsOnOffActuator.h"
#include "config.h"
#include "Debug.h"
#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"
#include <CRC16.h>

namespace AHGSystems {
/**
 *
 */
clsOnOffActuator::clsOnOffActuator() {
	//
//	pController 	= nullptr;
	m_i8PortNumber 	= -1;
	m_u8DeviceType 	= DEV_TYPE_END;
	m_szDeviceID	= "";
	m_szDescription = "";
	m_i16Value 		= ACTUATOR_STATUS_OFF;
	m_pRS485 		= nullptr;
	m_i8PortNumber 	= -1;
	m_pMutex		= new std::mutex();
	m_bIsVisible 	= true;
	m_u16SMBusID 	= 0x00;
	m_szGatewayID 	= "";
	m_jsonBuilder.Clear();
}

clsOnOffActuator::~clsOnOffActuator() {
	//
}
/**
 *
 * @param pCtrl
 * @param i8PortNumber
 * @param pMutex
 */
void clsOnOffActuator::SetController(clsRS485* pCtrl)
{
	if(pCtrl == nullptr)
		return;

	m_pRS485 = pCtrl;
//	m_pMutex = pMutex;

//	if((i8PortNumber > SMARTBUS_RELAY_MAXIMUM_PORT ) || (i8PortNumber < 0))
//		return;


}

void clsOnOffActuator::SetHWAddress(uint16_t u16DeviceAddr, int8_t i8PortNumber)
{
	m_i8PortNumber = i8PortNumber;
	m_u16SMBusID = u16DeviceAddr;
}

/**
 *
 * @param u16Cmd
 * @param u16DevType
 * @return
 */
int16_t	clsOnOffActuator::ExecuteCommand(uint16_t u16Cmd, uint16_t u16DevType)
{
	if(m_pRS485 == nullptr)
	{
		LREP("[Firmware][ERR] %s.%d :Controller is not set!", __FILE__, __LINE__);
		return ACTUATOR_STATUS_OFF;
	}

	int16_t	bResponse = -1;

	uint8_t data[] = { 0xAA, 0xAA,
						0x0F,
						0x0C, 0xFE,
						0xFF, 0xFE,
						0x00, 0x31,
						0x01, 0x0C, 	// Dst addr
						0x01, 0x64, 0x00, 0x01,
						0xB2, 0x2F };

	data[SMBUS_FRM_IDX_DST_SUB_ID] = (m_u16SMBusID >> 8) & 0xFF;
	data[SMBUS_FRM_IDX_DST_DEV_ID] = m_u16SMBusID & 0xFF;

	data[SMBUS_FRM_IDX_DST_DATA0] = 0xFF & (m_i8PortNumber);
	ProtoFrame_t sFrame;
	sFrame.len = sizeof(data);

	m_pMutex->lock();
	switch (u16Cmd)
	{
		case CMD_ACTUATOR_ON:
			data[SMBUS_FRM_IDX_DST_DATA0+1] = 0x64;
			Pack_crc(&data[2], sizeof(data) - 4);
			sFrame.data = new uint8_t[sFrame.len];
			memcpy(sFrame.data, data, sizeof(data));


			bResponse = m_pRS485->SendData(sFrame);
			break;
		case CMD_ACTUATOR_OFF:
			data[SMBUS_FRM_IDX_DST_DATA0+1] = 0x00;
			Pack_crc(&data[2], sizeof(data) - 4);

			sFrame.data = new uint8_t[sFrame.len];
			memcpy(sFrame.data, data, sizeof(data));

			bResponse = m_pRS485->SendData(sFrame);
			break;
		case CMD_ACTUATOR_GET_ON_OFF:
			bResponse = m_i16Value;
			break;
		default:
			break;
	}
	m_pMutex->unlock();

	return bResponse;
}

/**
 *
 * @param pvArgs: SMBus Frame received from RS485 RxThread
 * @return	0xFF: if pvArg is null
 * 			0x00: success
 */
uint8_t	clsOnOffActuator::UpdateValues(void *pvArgs)
{
	if(pvArgs == nullptr)
	{
		return 0xFF;
	}

	else
	{
//		TransSmartBus::SMBusFrame_t* pFrame = (TransSmartBus::SMBusFrame_t*)pvArgs;
		TransSmartBus::SMBusFrame_t pFrame =
						TransSmartBus::clsTransSmartBus::DecodeFrame((uint8_t*) pvArgs);

//		if((((uint16_t)pFrame->src_subid << 8)+pFrame->src_devid == m_u16SMBusID))
//		{
//
//			LREP_ERROR("\r\n[clsOnOffActuator] Decoded frame: len: %.2x, src: %.2x%.2x, type: %.4x, op: %.4x, dst: %.2x%.2x, crc: %.4x",
//					pFrame->dlen,
//					pFrame->src_subid, pFrame->src_devid,
//					pFrame->devtype,
//					pFrame->opcode,
//					pFrame->dst_subid, pFrame->dst_devid,
//					pFrame->crc);
//		}

		// Invalid CRC case --> Request channels status
		if(pFrame.dlen == 0)
		{
			LREP("SMBUS Invalid CRCD, request current status of channels");
//			RequestRelayBoxStatus();
			return 0xFF;
		}

		// Response of Read channels request
		if(
				(pFrame.opcode == SMBUS_MSG_TYPE_READ_STATUS_RESPONSE)
				&& (((uint16_t)pFrame.src_subid << 8)+pFrame.src_devid == m_u16SMBusID)
				&& (pFrame.devtype != SMBUS_DEV_TYPE_RELAY)
			)
		{
			LREP_RAW("%s:%d: got READ STATUS RESPOSE Frame ", __FILE__, __LINE__);
			for(int i = 0; i < pFrame.dlen - SMBUS_FRM_HDR_SIZE; i ++)
			{
				LREP_RAW("%.2x ", pFrame.data[i]);

			}
			LREP("");

			// TODO: [manhbt] Update channel current status

			return 0xFF;
		}


		// Response from relay status changed
		if ((pFrame.opcode != SMBUS_MSG_TYPE_SINGLE_CHANNEL_CONTROL_RESPONSE) ||
				(((uint16_t)pFrame.src_subid << 8)+pFrame.src_devid != m_u16SMBusID) || (pFrame.devtype != SMBUS_DEV_TYPE_RELAY))
		{
//			LREP_ERROR("Invalid parameter! smid: %.4x, opcode: %.4x, id: %.4x, type: %.4x",
//					m_u16SMBusID,
//					pFrame.opcode,
//					((uint16_t)pFrame.src_subid << 8)+pFrame.src_devid,
//					pFrame.devtype);
			return 0xFF;
		}

		// TODO: Check CRC
//		LREP("CRC: cal:%.4x, get: %.4x", CalculateCRC16(pFrame.data, pFrame.dlen), pFrame.crc);

		uint8_t u8NewStatus = ((pFrame.data[4] >> (uint8_t)(m_i8PortNumber - 1)) & 0x01) ? 1 : 0;

		if(u8NewStatus != m_i16Value)
		{
			for(auto itr = m_lstInternalCallbackFunctions.begin(); itr != m_lstInternalCallbackFunctions.end(); itr++ )
			{
				itr->first(m_szDeviceID, (char*)&u8NewStatus, itr->second);
			}

			m_pMutex->lock();

			m_i16Value = u8NewStatus;


//			rapidjson::StringBuffer s;
			m_jsonBuilder.Clear();
			rapidjson::Writer<rapidjson::StringBuffer> writer(m_jsonBuilder);

			writer.StartObject();               // Between StartObject()/EndObject(),

			writer.Key("device_type");
			writer.Int(m_u8DeviceType);

			writer.Key("device_id");
			writer.String(m_szDeviceID.c_str());

			writer.Key("gateway_id");
			writer.String(m_szGatewayID.c_str());


			writer.Key("device_description");
			writer.String(m_szDescription.c_str());

			char tmp[10];

			writer.Key("hardware_address");
			sprintf(tmp, "%.4x:%.2x", m_u16SMBusID, m_i8PortNumber);
			writer.String(tmp);

			writer.Key("device_values");
			writer.StartArray();
			// Air temperature
			writer.StartObject();
			writer.Key("param");
			writer.String("actuator_state");

			writer.Key("value");
			writer.Int(m_i16Value);
			writer.EndObject();

			writer.EndArray();
			writer.EndObject();

//			LREP_WARNING("%p",(char*)&m_jsonBuilder );
			for(auto itr = m_lstCallbackFunctions.begin(); itr != m_lstCallbackFunctions.end(); itr++ )
			{
//				cbFcn(m_szDeviceID, (char*)m_jsonBuilder.GetString());
				itr->first(m_szDeviceID, (char*)m_jsonBuilder.GetString(), itr->second);
			}
			m_pMutex->unlock();
		}

		return 0;
	}
}


char*	clsOnOffActuator::GetCurrentStatus()
{
	char* pcResult = nullptr;
	m_pMutex->lock();
	pcResult = (char*)m_jsonBuilder.GetString();
	m_pMutex->unlock();

	return pcResult;
}

void	clsOnOffActuator::RegisterInternalCallback(CallbackFunction fcn, std::string szGWID, void* pvParent)
{
	if(fcn != nullptr)
	{
		m_lstInternalCallbackFunctions.insert(std::make_pair(fcn, pvParent));
	}
}

void	clsOnOffActuator::RegisterCallback(CallbackFunction fcn, std::string szGWID, void* pvParent)
{
	if(fcn != nullptr)
	{
//		m_lstCallbackFunctions.push_back(fcn);
		m_lstCallbackFunctions.insert(std::make_pair(fcn, pvParent));
		m_szGatewayID = szGWID;

		m_pMutex->lock();
		m_jsonBuilder.Clear();
		rapidjson::Writer<rapidjson::StringBuffer> writer(m_jsonBuilder);

		writer.StartObject();               // Between StartObject()/EndObject(),

		writer.Key("device_type");
		writer.Int(m_u8DeviceType);

		writer.Key("device_id");
		writer.String(m_szDeviceID.c_str());

		writer.Key("gateway_id");
		writer.String(m_szGatewayID.c_str());


		writer.Key("device_description");
		writer.String(m_szDescription.c_str());

		char tmp[10];

		writer.Key("hardware_address");
		sprintf(tmp, "%.4x:%.2x", m_u16SMBusID, m_i8PortNumber);
		writer.String(tmp);

		writer.Key("device_values");
		writer.StartArray();
		// Air temperature
		writer.StartObject();
		writer.Key("param");
		writer.String("actuator_state");

		writer.Key("value");
		writer.Int(m_i16Value);
		writer.EndObject();

		writer.EndArray();
		writer.EndObject();

		m_pMutex->unlock();
	}
}


void clsOnOffActuator::RequestRelayBoxStatus()
{
	uint8_t data[] = {0xAA, 0xAA, 0x0B, 0xFF, 0xFF, 0x00, 0x17, 0x00, 0x33, 0x01, 0x01, 0xE9, 0xEE};



	data[9] = (m_u16SMBusID >> 8) & 0xFF;
	data[10] = m_u16SMBusID & 0xFF;

	Pack_crc(&data[2], sizeof(data)-4);

//	Check_crc(&data[2], sizeof(data)-4);
//	{
//		printf("\r\nCheck_crc OK\r\n");
//	}

	ProtoFrame_t sFrame;
	sFrame.len = sizeof(data);
	sFrame.data = new uint8_t[sFrame.len];
	memcpy(sFrame.data, data, sFrame.len);

	printf("RS485 sent bytes: \r\n");
	for (uint8_t i = 0; i < sizeof(data); i++) {
		printf(" 0x%02X", data[i] & 0xFF);
	}
	std::cout<<std::endl;

	m_pRS485->SendData(sFrame);

}


} /* namespace Agriculture */
