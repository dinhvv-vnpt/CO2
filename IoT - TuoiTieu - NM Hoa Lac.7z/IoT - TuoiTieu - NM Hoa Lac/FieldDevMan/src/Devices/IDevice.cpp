/*
 * IDevice.cpp
 *
 *  Created on: May 10, 2017
 *      Author: MANHBT
 */

#include "IDevice.h"

namespace AHGSystems {

IDevice::IDevice() {
	//

}

IDevice::~IDevice() {
	//
}

int16_t		 			IDevice::ExecuteCommand(const char* szCmd)
{
	return -1;
}

//void RegisterCallback(CallbackFunction fcn, std::string szGWID)
//{}

} /* namespace Agriculture */
