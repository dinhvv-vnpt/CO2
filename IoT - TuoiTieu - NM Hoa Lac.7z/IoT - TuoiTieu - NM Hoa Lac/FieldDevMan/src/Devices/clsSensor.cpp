/*
 * clsSensor.cpp
 *
 *  Created on: May 10, 2017
 *      Author: MANHBT
 */

#include "clsSensor.h"
#include "TransRSP/clsTransRSP.h"
#include "config.h"
#include "Debug.h"
#include <string>
#include <ctime>
#include <iostream>
#include <CRC8.h>
#include <CRC16.h>


namespace AHGSystems {

clsSensor::clsSensor() {
	m_u8SensorType = DEV_TYPE_END;
	m_u16RSPId = 0;
	m_pConnHandler = nullptr;
//	m_pUartMutex = nullptr;
	m_pSensorMutex = new std::mutex();

	m_szDescription = "";
	m_szDeviceID = "";
	m_i16Value = -1;
	m_bIsVisible = true;
//	m_sSensValue.air_temp = 0xEFFF;
//	m_sSensValue.air_humid = 0xEFFF;
//	m_sSensValue.soil_temp = 0xEFFF;
//	m_sSensValue.soil_humid = 0xEFFF;

	m_lstCallbackFunctions.clear();
#if (SENS_ERROR_LOG_ENABLE == ON)
	char buff[100];

	time_t t = time(0);   // get time now
	struct tm * now = localtime( & t );

	snprintf(
			buff,
			sizeof(buff),
			"FieldDevMan_%.2d%.2d%.2d%.2d%.2d%.2d.log",
			now->tm_year+1900,
			now->tm_mon,
			now->tm_mday,
			now->tm_hour,
			now->tm_min,
			now->tm_sec
	);
	m_szSensLogFileName = buff;
	LREP ("Logfile name: %s", buff);
	LREP ("Creating logfile %s for sensor...", m_szSensLogFileName.c_str());
	char cmd[1024];

	snprintf(
			cmd, sizeof(cmd),
			"echo \"[%.2d-%.2d-%.2d %.2d:%.2d:%.2d] *************** APP STARTED **************\" >> %s",
			now->tm_year+1900,
			now->tm_mon,
			now->tm_mday,
			now->tm_hour,
			now->tm_min,
			now->tm_sec,
			(char*)m_szSensLogFileName.c_str()
	);
	system(cmd);
#endif
}

clsSensor::~clsSensor() {
}

bool clsSensor::SetConnHandler(clsRS485* pHandler)
{
	if (pHandler == nullptr)
	{
		return false;
	}

	m_pConnHandler = pHandler;
//	m_pUartMutex = pUartMutex;
	return true;
}

/**
 * @brief GetResponse
 * @param devID string of device ID
 * @param u16Cmd command in command list
 * @param u16SubCmd sensor type:
 * @return for sensor node: return 0xEFFF if error,
 *                          return sensor value in case of succes
 *         for valve and pump: return EFFF if error occur
 *                      for command: get/set status return current status
 *                      ACTUATOR_STATUS_ON/OFF of valve and pump
 */
/**
 * Request/Process Update data from Sensor nodes
 * @param pvArgs: RSP frame
 * 		is null: Sensor node update request
 * 		!= null: RSP frame received from RS485 Bus --> need to update sensor data
 * @return
 */
uint8_t clsSensor::UpdateValues(void *pvArgs)
{
	if (m_pConnHandler == nullptr)
	{
		std::cout << "[SENS] Controller is not set!" << std::endl;
		return SENS_RESPONSE_HW_ERROR;
	}

	// Process Sensor node Update Request : Send request Frame to RS485 Tx queue
	if (pvArgs == nullptr)
	{
#if (SENS_DEBUG_ENABLE == ON)
		LREP("Sending RSP request...");
#endif
		/**
		 * RSP Frame structure
		 * 0_____2______4______5_____6_____8_____10______11__________________________
		 * +-----+------+------+-----+-----+-----+-------+-------------+-------+-----+
		 * | SOF | DLEN | FLAG | SEQ | DST | SRC | CRC_H | DATA[0...n] | CRC_D | EOF |
		 * | (2) |  (2) |  (1) | (1) | (2) | (2) |  (1)  |   (DLEN)    |  (2)  | (1) |
		 * +-----+------+------+-----+-----+-----+-------+-------------+-------+-----+
		 */
		uint8_t data[] = { 0x55, 0x55, 	// sof  - idx = 0
				0x00, 0x02, 	// dlen	- idx = 2
				0x00, 			// flag - idx = 4
				0x00, 			// seq -  idx = 5
				0x00, 0x01,		// dst - idx = 6
				0x00, 0xff,		// src - idx = 8
				0x00,			// crc_h - idx = 10
				0x01, 0x02,		// Data[0] - idx = 11
				0x00, 0x00,		// crc
				0xff			// eof
				};

//		m_pUartMutex->lock();

		if (m_pConnHandler->SetMode(8, mraa::UART_PARITY_EVEN, 1)
				!= mraa::SUCCESS) {
#if (SENS_DEBUG_ENABLE == ON)
			LREP("[FieldDevMan].[SENS] Error while changing comm parity mode, error code: %d",
					m_pConnHandler->SetMode(8, mraa::UART_PARITY_EVEN, 1));
#endif
		}


#if (SENS_DEBUG_ENABLE == ON)
		LREP("RSP ID: %x", m_u16RSPId);
#endif


		data[RSP_FRM_IDX_DSTADDR] = (m_u16RSPId >> 8)&0xFF;
		data[RSP_FRM_IDX_DSTADDR+1] = m_u16RSPId & 0xFF;

		/**
		 * RSP Frame structure
		 * 0_____2______4______5_____6_____8_____10______11__________________________
		 * +-----+------+------+-----+-----+-----+-------+-------------+-------+-----+
		 * | SOF | DLEN | FLAG | SEQ | DST | SRC | CRC_H | DATA[0...n] | CRC_D | EOF |
		 * | (2) |  (2) |  (1) | (1) | (2) | (2) |  (1)  |   (DLEN)    |  (2)  | (1) |
		 * +-----+------+------+-----+-----+-----+-------+-------------+-------+-----+
		 */

		//calculate CRC_H
		data[RSP_FRM_IDX_CRCH] = CalCRC8(&data[RSP_FRM_IDX_DLEN], 8);
		uint16_t u16Dlen = 2;
		// Calculate CRC_D
		uint16_t u16CRCD = CalculateCRC16(&data[RSP_FRM_IDX_CRCH], u16Dlen + 1);
//		*(uint16_t*)&data[RSP_FRM_IDX_DATA0 + u16Dlen] = htons(CalculateCRC16(&data[RSP_FRM_IDX_CRCH], u16Dlen + 1));
		data[RSP_FRM_IDX_DATA0 +  u16Dlen] = (u16CRCD >> 8) & 0xFF;
		data[RSP_FRM_IDX_DATA0 +  u16Dlen + 1] = (u16CRCD) & 0xFF;

		// Build ProtoFrame_t object and push to Tx queue
		ProtoFrame_t frame;
		frame.len = sizeof(data);
		frame.data = new uint8_t[frame.len];
		memcpy(frame.data, data, frame.len);

		// Push RSP Frame to RS485 Tx Queue
		m_pConnHandler->SendData(frame);


//		m_pUartMutex->unlock();
		// TODO: disable debug message on release version
#if(SENS_DEBUG_ENABLE == ON)
		printf("uart write bytes\r\n");

		for (uint32_t i = 0; i < sizeof(data); i++) {
			printf(" 0x%02X", data[i] & 0xFF);
		}
		std::cout << std::endl;
#endif

		return SENS_RESPONSE_OK;
	}

	// Process Received RSP Frame (Response frame form Sensor node)
	else {
		TransRSP::RSPFrame_t* pFrame = (TransRSP::RSPFrame_t*) pvArgs;

		if (htons(pFrame->srcaddr) != m_u16RSPId) {
			return 0xFF;
		}

		uint8_t* pu8DataPayload = (uint8_t*)pvArgs + RSP_FRM_IDX_DATA0 + 2 - RSP_FRM_SOF_SIZE;

#if(SENS_DEBUG_ENABLE == ON)
		LREP("\r\n[clsSensor] Decoded frame: len: %.2x, flags: %.2x, dst: %.4x, src: %.4x, crch: %.2x, crcd: %.4x",
				ntohs(pFrame->dlen),
				pFrame->flags,
				pFrame->seq,
				ntohs(pFrame->dstaddr),
				ntohs(pFrame->srcaddr),
				pFrame->crch,
				ntohs(pFrame->crcd)
		);
		LREP_RAW("[clsSensor] Data: ");
		for (uint32_t i = 0; i < ntohs(pFrame->dlen); i++) {
			printf(" %.2x",  pu8DataPayload[i]);
		}
#endif


		uint16_t u16SensorDataLen = ntohs(*(uint16_t*)((uint8_t*)pvArgs + RSP_FRM_IDX_DLEN - RSP_FRM_SOF_SIZE)) - 2;
//		LREP("[%s:%d] Sensor data len: %d", __FILE__, __LINE__, u16SensorDataLen);

		if ((u16SensorDataLen %3) != 0)
		{
			LREP("Invalid Sensor data payload length: %d", u16SensorDataLen);
			return SENS_RESPONSE_INVALID_PARAMS;
		}

		uint8_t* status = new uint8_t[u16SensorDataLen + 2];
		status[0] = (u16SensorDataLen >> 8) & 0xFF;
		status[1] = (u16SensorDataLen) & 0xFF;
		memcpy(&status[2], pu8DataPayload, u16SensorDataLen);
//		for (int i = 2; i < u16SensorDataLen; i ++)
//			status[i] = pu8DataPayload[i-2];

		for (auto itr = m_lstInternalCallbackFunctions.begin(); itr != m_lstInternalCallbackFunctions.end(); itr++)
		{
			itr->first(m_szDeviceID, (char*)status, itr->second);
		}

		delete status;

		m_pSensorMutex->lock();

		// Serialize the sensor data (JSON Formatted)
		m_jsonBuilder.Clear();
		rapidjson::Writer<rapidjson::StringBuffer> writer(m_jsonBuilder);

		writer.StartObject();               // Between StartObject()/EndObject(),

		writer.Key("device_type");
		writer.Int(m_u8SensorType);

		writer.Key("device_id");                // output a key,
		writer.String(m_szDeviceID.c_str());             // follow by a value.

		writer.Key("gateway_id");
		writer.String(m_szGatewayID.c_str());

		writer.Key("device_description");
	    writer.String(m_szDescription.c_str());

	    char tmp[10];

	    writer.Key("hardware_address");
	    sprintf(tmp, "%.4x", m_u16RSPId);
	    writer.String(tmp);

	    writer.Key("device_values");
	    writer.StartArray();


		for(uint16_t idx = 0; idx < u16SensorDataLen/3; idx++)
		{
			writer.StartObject();

			// type
			writer.Key("param");

			writer.String(g_SensorKeyword[pu8DataPayload[idx*3]]);

			// value
			writer.Key("value");
			writer.Double((double)(ntohs(*(uint16_t*) &pu8DataPayload[idx*3+1]))/100);
			writer.EndObject();

		}


	    // all values are elements of the array.
	    writer.EndArray();
	    writer.EndObject();


//		for(auto cbFcn : m_lstCallbackFunctions)
//		{
//			cbFcn(m_szDeviceID, (char*)m_jsonBuilder.GetString());
//		}

	    for (auto itr = m_lstCallbackFunctions.begin(); itr != m_lstCallbackFunctions.end(); itr++)
	    {
	    	itr->first(m_szDeviceID, (char*)m_jsonBuilder.GetString(), itr->second);
	    }
		m_pSensorMutex->unlock();

		return SENS_RESPONSE_OK;
	}

}

/**
 *	Execute command
 * @param u16Cmd: Command <-> Command (read values command)
 * @param u16SubCmd: Sub-Command <-> Device type
 * @return: value of sensor
 */
int16_t clsSensor::ExecuteCommand(uint16_t u16Cmd, uint16_t u16SubCmd) {
	//	u16SubCmd = u16SubCmd;
	int16_t i16Result = 0xEFFF;
	if (u16SubCmd != m_u8SensorType) {
#if (SENS_DEBUG_ENABLE == ON)
		LREP("Device Type Invalid");
#endif
		return i16Result;
	}

	switch (u16Cmd) {
//	case CMD_SENSOR_AIR_HUMIDITY_GET_VALUE:
//		m_pSensorMutex->lock();
//		i16Result = m_sSensValue.air_humid;
//		m_pSensorMutex->unlock();
//		break;
//	case CMD_SENSOR_AIR_TEMPERATURE_GET_VALUE:
//		m_pSensorMutex->lock();
//		i16Result = m_sSensValue.air_temp;
//		m_pSensorMutex->unlock();
//		break;
//	case CMD_SENSOR_SOIL_HUMIDITY_GET_VALUE:
//		m_pSensorMutex->lock();
//		i16Result = m_sSensValue.soil_humid;
//		m_pSensorMutex->unlock();
//		break;
//	case CMD_SENSOR_SOIL_TEMPERATURE_GET_VALUE:
//		m_pSensorMutex->lock();
//		i16Result = m_sSensValue.soil_temp;
//		m_pSensorMutex->unlock();
//		break;
	default:
		std::cout << "Invalid Command!" << std::endl;
		break;
	}

	return i16Result;

}

/**
 * Register callback function
 * @param fcn invoked when status of sensor node changes (values changed)
 */
void	clsSensor::RegisterCallback(CallbackFunction fcn,std::string szGWID, void* pvParent)
{
	if(fcn != nullptr)
	{
//		m_lstCallbackFunctions.push_back(fcn);
		m_lstCallbackFunctions.insert(std::make_pair(fcn, pvParent));
		m_szGatewayID = szGWID;

		// Update current status
		m_pSensorMutex->lock();

		// Serialize the sensor data (JSON Formatted)
		m_jsonBuilder.Clear();
		rapidjson::Writer<rapidjson::StringBuffer> writer(m_jsonBuilder);

		writer.StartObject();               // Between StartObject()/EndObject(),

		writer.Key("device_type");
		writer.Int(m_u8SensorType);

		writer.Key("device_id");                // output a key,
		writer.String(m_szDeviceID.c_str());             // follow by a value.

		writer.Key("gateway_id");
		writer.String(m_szGatewayID.c_str());

		writer.Key("device_description");
		writer.String(m_szDescription.c_str());

		char tmp[10];

		writer.Key("hardware_address");
		sprintf(tmp, "%.4x", m_u16RSPId);
		writer.String(tmp);

		writer.Key("device_values");
		writer.StartArray();

		// all values are elements of the array.
		writer.EndArray();
		writer.EndObject();

		m_pSensorMutex->unlock();
	}
}


void 			clsSensor::RegisterInternalCallback(CallbackFunction fcn, void* pvParent)
{
	if(fcn != nullptr)
	{
	//		m_lstCallbackFunctions.push_back(fcn);
		m_lstInternalCallbackFunctions.insert(std::make_pair(fcn, pvParent));
	}
}
/**
 * Get the current status of Sensor node
 * @return: json formated string, contains the all status off sensor node
 */
char*	clsSensor::GetCurrentStatus()
{
	char* pcResult = nullptr;
	m_pSensorMutex->lock();
	pcResult = (char*)m_jsonBuilder.GetString();
	m_pSensorMutex->unlock();

	return pcResult;
}

} /* namespace Agriculture */


