/*
 * SensorType.c
 *
 *  Created on: Jul 17, 2017
 *      Author: MANHBT
 */
#if 1
const char* g_SensorKeyword[] = {
	"unknown_type",
	"air_temperature",
	"air_humidity",
	"soil_temperature",
	"soil_moisture",
	"light_ambient",
	"water_ec",
	"water_ph",
	"water_temperature",
	"water_level",
	"soil_ec",
	"soil_ph",
	"water_buoy",
};


#else
// Faked data
const char* g_SensorKeyword[] = {
	"unknown_type",
	"water_temperature",
	"water_EC",
	"water_PH",
	"water_level",
	"light_ambient",
	"water_ec",
	"water_ph",
	"water_temperature",
	"water_level"
};
#endif
