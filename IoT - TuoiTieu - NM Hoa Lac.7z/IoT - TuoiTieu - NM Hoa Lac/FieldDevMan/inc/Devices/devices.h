/*
 * devices.h
 *
 *  Created on: Jun 5, 2017
 *      Author: buiti
 */

#ifndef DEVICES_DEVICES_H_
#define DEVICES_DEVICES_H_

#include <ahg.h>
#include <config.h>

/**
 * Controllers
 */
#include "Controller/clsGPIOController.h"
//#include "Controller/clsSmartBusRelayController.h"
//#include "Controller/clsShiftedIOController.h"

/**
 * Devices Include
 */
//#include "clsPushButton.h"

#if (APP_TYPE == APP_TYPE_SMART_AGRICULTURE)
/**
 * Organic4U
 */
//#include "clsOnOffActuator.h"
#include "clsOnOffActuator.h"
#include "clsSensor.h"
#include "clsCO2Sensor.h"
#elif (APP_TYPE == APP_TYPE_SMART_FACTORY)
/**
 * V-Factory
 */
#include "clsProductCounter.h"
#include "clsTM1637Display.h"
#include "clsOnOffActuator.h"

#elif (APP_TYPE == APP_TYPE_SMART_HOME)
/**
 * V-Home
 */
#include "clsAM2315.h"
#include "clsBH1750.h"
#include "clsKN45CurtainMotor.h"
#include "clsOnOffActuator.h"
#endif




#endif /* DEVICES_DEVICES_H_ */
