/*
 * clsCO2Sensor.h
 *
 *  Created on: May 10, 2017
 *      Author: MANHBT
 */

#ifndef clsCO2Sensor_H_
#define clsCO2Sensor_H_

#include "IDevice.h"
#include "IComm.h"
#include <ahg.h>
#include <thread>
#include <mutex>
#include <unordered_map>
#include <arpa/inet.h>
#include <clsRS485.h>
#include <iostream>
#include "config.h"
#include <list>
#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"
#include "SensorType.h"

namespace AHGSystems {

class clsCO2Sensor: public IDevice {
private:

	struct {
		float 	dCO2;
		float	dAirTemp;
	} m_sSensorValues;

	DevType_t 						m_u8SensorType;
	std::string 					m_szDeviceID;
	std::string 					m_szDescription;
	std::string						m_szGatewayID;
	bool							m_bIsVisible;

	mraa::Gpio*						m_pRS485DEPin;
	mraa::Uart* 					m_pRS485UartHandler;

	std::mutex*						m_pSensorMutex;
	std::unordered_map<CallbackFunction, void*> 	m_lstCallbackFunctions;
	std::unordered_map<CallbackFunction, void*> 	m_lstInternalCallbackFunctions;
    rapidjson::StringBuffer 		m_jsonBuilder;

    pthread_t						m_pSensorUpdateTheadProc;

#if (SENS_ERROR_LOG_ENABLE == ON)
	std::string 	m_szSensLogFileName;
#endif
	char* 					GenerateJson(void);
	void					SensorThreadProc(void *pArgs, bool *bIsTerminate);
public:
	clsCO2Sensor();

	virtual ~clsCO2Sensor();

	uint8_t 			UpdateValues(void *pvArgs) override;

//	// Implement IDevice Functions
	void 				SetDeviceID(std::string szDeviceID) override {m_szDeviceID = szDeviceID;}
	std::string 		GetDeviceID() override {return m_szDeviceID;}


	void 				SetDeviceDescription(std::string szDescription) override {m_szDescription = szDescription;}
	std::string 		GetDeviceDescription() override {return m_szDescription;}

	void 				SetDevType(DevType_t u8DevType) override { m_u8SensorType = u8DevType;}
	DevType_t 			GetDevType() override {return m_u8SensorType;}

	uint16_t 			ReadValue() override {return 0xEFFF;}
	bool				IsVisible() override {return m_bIsVisible;}
	void				SetVisible(bool visible) override {m_bIsVisible = visible;}

	char*		 		GetCurrentStatus();
//	void				RegisterCallback(CallbackFunction fcn, std::string szGWID) override;
	void				RegisterCallback(CallbackFunction fcn, std::string szGWID, void* pvParent) override;
	void 				RegisterInternalCallback(CallbackFunction fcn, void* pvParent);
	int16_t 			ExecuteCommand(uint16_t u16Cmd, uint16_t u16SubCmd) override;
	int16_t    			calculator_crc16(const char * data, int lengh );
};

} /* namespace Agriculture */

#endif /* clsCO2Sensor_H_ */
